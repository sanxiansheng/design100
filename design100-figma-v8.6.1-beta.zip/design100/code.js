var UI_WIDTH = 360;
var UI_MIN_HEIGHT = 218;
var UI_MAX_HEIGHT = 560;
figma.showUI(__html__, { width: UI_WIDTH, height: 240, themeColors: true });

var DEFAULTS = {
  maxIconExports: 120,
  maxImageExports: 40,
  maxSvgRootPixels: 12000000,
  maxPreviewPixels: 1800000,
  previewScale: 0.5,
  maxInlineSvgNodePixels: 65536,
  minIconSize: 4
};

function progress(message, percent){ figma.ui.postMessage({ type:'PROGRESS', message:message, percent:percent || 0 }); }
function postSelection(){ var selection=figma.currentPage.selection||[]; var first=selection[0]||null; figma.ui.postMessage({ type:'SELECTION', name:first?first.name:'', nodeType:first?first.type:'', count:selection.length }); }
function safeClone(value){ if(value===figma.mixed) return 'MIXED'; if(value===undefined) return undefined; try{return JSON.parse(JSON.stringify(value));}catch(e){return null;} }
function bytesToText(bytes){ try{return new TextDecoder('utf-8').decode(bytes);}catch(e){ var s=''; for(var i=0;i<bytes.length;i++) s+=String.fromCharCode(bytes[i]); try{return decodeURIComponent(escape(s));}catch(_){return s;} } }
function rgbToHex(c){ if(!c) return null; return '#'+[c.r,c.g,c.b].map(function(v){return Math.max(0,Math.min(255,Math.round(v*255))).toString(16).padStart(2,'0');}).join('').toUpperCase(); }
function safeName(name){ return (name||'node').replace(/[^a-z0-9\u4e00-\u9fa5_-]+/gi,'-').replace(/^-+|-+$/g,'') || 'node'; }
function isVisible(node){ return node && node.visible !== false; }
function nodeArea(node){ return Math.max(0,node.width||0) * Math.max(0,node.height||0); }
function includesAny(text, arr){ text=(text||'').toLowerCase(); for(var i=0;i<arr.length;i++){ if(text.indexOf(arr[i])>=0) return true; } return false; }
function parentPath(node){ var out=[]; var n=node; while(n && n.type !== 'DOCUMENT'){ out.unshift(n.name || n.type); n=n.parent; } return out.join(' / '); }


var PLUGIN_VERSION = 'v8.6.1';
var PACKAGE_SCHEMA_VERSION = '0.8';
var SNAPSHOT_PREFIX = 'aiui:snapshot:';

function randomId(prefix){
  var time=Date.now().toString(36), rand='';
  for(var i=0;i<12;i++) rand+=Math.floor(Math.random()*36).toString(36);
  return (prefix||'aiui')+'_'+time+'_'+rand;
}
function getNodeData(node,key){ return safeRead('getPluginData:'+key,function(){ return node.getPluginData?node.getPluginData(key):''; },'') || ''; }
function setNodeData(node,key,value){ return safeRead('setPluginData:'+key,function(){ if(node.setPluginData) node.setPluginData(key,String(value||'')); return true; },false); }
function getAiuiNodeId(node){ return getNodeData(node,'aiuiNodeId') || ('figma_'+String(node.id||'node').replace(/[^a-z0-9_-]/gi,'_')); }
function readSyncContext(root){ var projectId=getNodeData(root,'aiuiProjectId'), rootAiuiNodeId=getNodeData(root,'aiuiNodeId'); return projectId&&rootAiuiNodeId?{projectId:projectId,rootAiuiNodeId:rootAiuiNodeId}:null; }
function validateBaselineRoot(root,baseline){
  var record=baseline.nodes&&baseline.nodes[baseline.rootAiuiNodeId];
  if(!record||record.figmaNodeId!==root.id)throw new Error('旧包不属于当前选中的原始节点，请选择正确的 Frame。');
  var sync=readSyncContext(root);
  if(sync&&(sync.projectId!==baseline.projectId||sync.rootAiuiNodeId!==baseline.rootAiuiNodeId))throw new Error('旧包项目与当前选区不匹配。');
}
function ensureSyncContext(root,baseline){
  var projectId=(baseline&&baseline.projectId)||getNodeData(root,'aiuiProjectId');
  if(!projectId){ projectId=randomId('project'); setNodeData(root,'aiuiProjectId',projectId); }
  else if(getNodeData(root,'aiuiProjectId')!==projectId) setNodeData(root,'aiuiProjectId',projectId);
  var preferredByFigmaId={};
  if(baseline&&baseline.nodes){ Object.keys(baseline.nodes).forEach(function(id){ var rec=baseline.nodes[id]; if(rec&&rec.figmaNodeId)preferredByFigmaId[rec.figmaNodeId]=rec.aiuiNodeId; }); }
  var seen={}; var assigned=0; var duplicates=0; var restored=0;
  function walk(node){
    var existing=getNodeData(node,'aiuiNodeId'), preferred=preferredByFigmaId[node.id], id='';
    if(preferred&&!seen[preferred]){ id=preferred; if(existing!==id){ if(setNodeData(node,'aiuiNodeId',id))restored++; } }
    else if(existing&&!seen[existing]) id=existing;
    else {
      if(existing&&seen[existing]) duplicates++;
      id=randomId('node');
      if(!setNodeData(node,'aiuiNodeId',id)) id='figma_'+String(node.id||randomId('fallback')).replace(/[^a-z0-9_-]/gi,'_');
      assigned++;
    }
    seen[id]=true;
    if('children' in node){ for(var i=0;i<node.children.length;i++) walk(node.children[i]); }
  }
  walk(root);
  var rootAiuiNodeId=(baseline&&baseline.rootAiuiNodeId)||getAiuiNodeId(root);
  if(getAiuiNodeId(root)!==rootAiuiNodeId)setNodeData(root,'aiuiNodeId',rootAiuiNodeId);
  setNodeData(root,'aiuiRootId',rootAiuiNodeId);
  return {projectId:projectId,rootAiuiNodeId:rootAiuiNodeId,assignedNodeIds:assigned,duplicateNodeIdsFixed:duplicates,restoredNodeIds:restored};
}
function snapshotKey(sync){ return SNAPSHOT_PREFIX+sync.projectId+':'+sync.rootAiuiNodeId; }
async function loadSnapshot(sync){ try{return await figma.clientStorage.getAsync(snapshotKey(sync)) || null;}catch(e){return null;} }
async function saveSnapshot(sync,snapshot){ try{await figma.clientStorage.setAsync(snapshotKey(sync),snapshot);return true;}catch(e){return false;} }
function roundValue(v){ if(typeof v==='number') return Math.round(v*1000)/1000; if(Array.isArray(v)) return v.map(roundValue); if(v&&typeof v==='object'){ var o={}; Object.keys(v).sort().forEach(function(k){ var x=roundValue(v[k]); if(x!==undefined)o[k]=x; }); return o; } return v; }
function stableStringify(value){ try{return JSON.stringify(roundValue(value));}catch(e){return String(value); } }
function hashString(text){ var h=2166136261; text=String(text||''); for(var i=0;i<text.length;i++){ h^=text.charCodeAt(i); h=Math.imul(h,16777619); } return ('00000000'+(h>>>0).toString(16)).slice(-8); }
function cloneWithout(obj,keys){ var out={}; if(!obj)return out; Object.keys(obj).forEach(function(k){ if(keys.indexOf(k)<0)out[k]=obj[k]; }); return out; }
function makeNodeRecord(node,parentAiuiNodeId,index){
  var text=node.text||null;
  var frame={x:node.x||0,y:node.y||0,width:node.width||0,height:node.height||0,rotation:node.rotation||0,relativeTransform:node.relativeTransform||null,absoluteBoundingBox:node.absoluteBoundingBox||null};
  var childIds=(node.children||[]).map(function(c){return c.aiuiNodeId;});
  var record={
    aiuiNodeId:node.aiuiNodeId,figmaNodeId:node.id,parentAiuiNodeId:parentAiuiNodeId||null,index:index||0,name:node.name,path:node.path,type:node.type,
    semanticType:node.semanticType,interactionState:node.interactionState,frame:frame,layout:node.layout||{},style:node.style||{},
    text:text,reactions:node.reactions||null,component:node.component||null,asset:node.asset||null,children:childIds
  };
  var typography=text?cloneWithout(text,['characters']):null;
  record.hashes={
    content:hashString(stableStringify({name:record.name,semanticType:record.semanticType,interactionState:record.interactionState,reactions:record.reactions,text:text?text.characters:null})),
    frame:hashString(stableStringify(frame)),
    layout:hashString(stableStringify(record.layout)),
    style:hashString(stableStringify(record.style)),
    typography:hashString(stableStringify(typography)),
    component:hashString(stableStringify(record.component)),
    asset:hashString(stableStringify(record.asset)),
    children:hashString(stableStringify(childIds))
  };
  return record;
}
function makeSnapshot(raw,sync,version){
  var nodes={};
  function walk(node,parentId,index){ var rec=makeNodeRecord(node,parentId,index); nodes[rec.aiuiNodeId]=rec; (node.children||[]).forEach(function(c,i){walk(c,rec.aiuiNodeId,i);}); }
  walk(raw,null,0);
  return {schema:'aiui-snapshot/v1',projectId:sync.projectId,rootAiuiNodeId:sync.rootAiuiNodeId,version:version,exportedAt:new Date().toISOString(),nodeCount:Object.keys(nodes).length,nodes:nodes};
}
function changedFields(before,after){
  var fields=[];
  if(before.hashes.content!==after.hashes.content){ if(before.name!==after.name)fields.push('name'); var bt=before.text&&before.text.characters,at=after.text&&after.text.characters; if(bt!==at)fields.push('text.characters'); if(before.semanticType!==after.semanticType)fields.push('semanticType'); if(before.interactionState!==after.interactionState)fields.push('interactionState'); if(stableStringify(before.reactions||null)!==stableStringify(after.reactions||null))fields.push('reactions'); }
  if(before.hashes.frame!==after.hashes.frame) fields.push('frame');
  if(before.hashes.layout!==after.hashes.layout) fields.push('layout');
  if(before.hashes.style!==after.hashes.style) fields.push('style');
  if(before.hashes.typography!==after.hashes.typography) fields.push('typography');
  if(before.hashes.component!==after.hashes.component) fields.push('component');
  if(before.hashes.asset!==after.hashes.asset) fields.push('asset');
  if(before.hashes.children!==after.hashes.children) fields.push('children');
  if(before.parentAiuiNodeId!==after.parentAiuiNodeId || before.index!==after.index) fields.push('positionInHierarchy');
  return fields;
}
function compactChangeSide(rec){ if(!rec)return null; return {aiuiNodeId:rec.aiuiNodeId,figmaNodeId:rec.figmaNodeId,parentAiuiNodeId:rec.parentAiuiNodeId,index:rec.index,name:rec.name,path:rec.path,type:rec.type,semanticType:rec.semanticType,interactionState:rec.interactionState,reactions:rec.reactions,frame:rec.frame,layout:rec.layout,style:rec.style,text:rec.text,component:rec.component,asset:rec.asset,children:rec.children}; }
function compareSnapshots(base,current){
  var changes=[], summary={added:0,removed:0,updated:0,moved:0,content:0,layout:0,style:0,typography:0,component:0,asset:0,hierarchy:0};
  var baseNodes=(base&&base.nodes)||{}, currentNodes=current.nodes||{};
  Object.keys(currentNodes).forEach(function(id){
    var after=currentNodes[id], before=baseNodes[id];
    if(!before){ changes.push({operation:'add',aiuiNodeId:id,name:after.name,path:after.path,changedFields:['node'],before:null,after:compactChangeSide(after)}); summary.added++; return; }
    var fields=changedFields(before,after); if(!fields.length)return;
    var moved=fields.indexOf('positionInHierarchy')>=0;
    changes.push({operation:moved&&fields.length===1?'move':'update',moved:moved,aiuiNodeId:id,name:after.name,path:after.path,changedFields:fields,before:compactChangeSide(before),after:compactChangeSide(after)});
    if(moved)summary.moved++; else summary.updated++;
    if(fields.some(function(f){return f==='name'||f==='text.characters'||f==='semanticType'||f==='interactionState'||f==='reactions';}))summary.content++;
    if(fields.indexOf('frame')>=0||fields.indexOf('layout')>=0)summary.layout++;
    if(fields.indexOf('style')>=0)summary.style++;
    if(fields.indexOf('typography')>=0)summary.typography++;
    if(fields.indexOf('component')>=0)summary.component++;
    if(fields.indexOf('asset')>=0)summary.asset++;
    if(fields.indexOf('children')>=0||fields.indexOf('positionInHierarchy')>=0)summary.hierarchy++;
  });
  Object.keys(baseNodes).forEach(function(id){ if(!currentNodes[id]){ var before=baseNodes[id]; changes.push({operation:'remove',aiuiNodeId:id,name:before.name,path:before.path,changedFields:['node'],before:compactChangeSide(before),after:null}); summary.removed++; } });
  changes.sort(function(a,b){ var order={remove:0,move:1,update:2,add:3}; return (order[a.operation]===undefined?9:order[a.operation])-(order[b.operation]===undefined?9:order[b.operation]) || String(a.path||'').localeCompare(String(b.path||'')); });
  return {schema:'aiui-changeset/v1',projectId:current.projectId,rootAiuiNodeId:current.rootAiuiNodeId,baseVersion:base.version,targetVersion:current.version,createdAt:new Date().toISOString(),summary:summary,changes:changes};
}
function findRawNodes(raw,ids){ var out={}; function walk(n){ if(ids[n.aiuiNodeId])out[n.aiuiNodeId]=n; (n.children||[]).forEach(walk); } walk(raw); return out; }
function makeUpdateMarkdown(changeset){
  var s=changeset.summary;
  var lines=['# AIUI 增量更新 v'+changeset.targetVersion,'','项目：`'+changeset.projectId+'`','版本：`v'+changeset.baseVersion+' → v'+changeset.targetVersion+'`','',
    '## 改动摘要','',
    '- 新增节点：'+s.added,'- 删除节点：'+s.removed,'- 更新节点：'+s.updated,'- 移动节点：'+s.moved,'- 内容变化：'+s.content,'- 布局变化：'+s.layout,'- 样式变化：'+s.style,'- 资源变化：'+s.asset,'',
    '## 给 Codex 的执行指令','',
    '读取 `update/changeset.json` 与 `update/changed-nodes.json`，按照 `agent/update.md` 修改现有工程。使用 `aiuiNodeId` 和项目中的 `.aiui/code-map.json` 定位代码；只修改变化部分，保留现有业务逻辑、状态、接口和交互；完成后运行构建与类型检查并更新 `.aiui/code-map.json`。','',
    '## 变化节点',''];
  changeset.changes.slice(0,200).forEach(function(c){ lines.push('- `'+c.operation+'` `'+c.aiuiNodeId+'` '+(c.path||c.name||'')+'：'+c.changedFields.join(', ')); });
  if(changeset.changes.length>200)lines.push('- 其余 '+(changeset.changes.length-200)+' 项请查看 changeset.json');
  return lines.join('\n')+'\n';
}
function makeUpdateAgent(){ return '# Incremental Update Protocol\n\n1. Read `update/changeset.json` first. Then follow `agent/component.md`, inspect existing `.aiui/component-map.json` and verify current component APIs before changing code.\n2. Read `update/changed-nodes.json` for the latest design data.\n3. Locate existing source with `.aiui/code-map.json` and `data-aiui-id`.\n4. Only change nodes listed in the changeset.\n5. Preserve existing business logic, state, APIs, event handlers, routing and accessibility behavior unless the changeset explicitly requires a change.\n6. For removed nodes, remove only the matching `aiuiNodeId`; do not delete unrelated code.\n7. For added nodes, insert them under `after.parentAiuiNodeId` and preserve hierarchy order.\n8. For layout/style/text changes, update the existing component rather than regenerating the whole page.\n9. Use current `tokens.json`, `color-token-report.json` and `assets-manifest.json`; never invent icons or images.\n10. Run build/typecheck/tests, then update `.aiui/code-map.json`, `.aiui/implementation-map.json` and `.aiui/current-version.json`. Maintain `.aiui/component-map.json`; preserve reusable components and shared defaults, and explain any extension or new component.\n11. Run `node verification/verify-aiui.mjs <generated-project-directory> --url http://localhost:PORT/page`. Do not deliver until it exits with code 0 and exported-content `executionCoverage` is 100.\n'; }
function makeCodeMapGuide(projectId,version){ return {schema:'aiui-code-map/v1',projectId:projectId||'REPLACE_WITH_PROJECT_ID',version:version||1,nodes:{'aiui_node_example':{file:'src/components/Example.tsx',component:'Example',selector:'[data-aiui-id="aiui_node_example"]'}}}; }

function paintToToken(paint){
  if(!paint || paint.visible===false) return null;
  if(paint.type==='SOLID') return { type:'solid', hex:rgbToHex(paint.color), opacity:paint.opacity==null?1:paint.opacity, blendMode:paint.blendMode||'NORMAL' };
  if(paint.type && paint.type.indexOf('GRADIENT')===0) return { type:paint.type, stops:safeClone(paint.gradientStops), transform:safeClone(paint.gradientTransform), opacity:paint.opacity==null?1:paint.opacity, blendMode:paint.blendMode||'NORMAL' };
  if(paint.type==='IMAGE') return { type:'image', imageHash:paint.imageHash, scaleMode:paint.scaleMode, imageTransform:safeClone(paint.imageTransform), scalingFactor:paint.scalingFactor, rotation:paint.rotation, opacity:paint.opacity==null?1:paint.opacity, blendMode:paint.blendMode||'NORMAL', filters:safeClone(paint.filters||null) };
  return safeClone(paint);
}
function styleOf(node){ var style={};
  if('fills' in node && node.fills!==figma.mixed) style.fills=node.fills.map(paintToToken).filter(Boolean);
  if('strokes' in node && node.strokes!==figma.mixed) style.strokes=node.strokes.map(paintToToken).filter(Boolean);
  if('strokeWeight' in node) style.strokeWeight=safeClone(node.strokeWeight);
  if('strokeAlign' in node) style.strokeAlign=safeClone(node.strokeAlign);
  if('dashPattern' in node) style.dashPattern=safeClone(node.dashPattern);
  if('cornerRadius' in node) style.cornerRadius=safeClone(node.cornerRadius);
  if('topLeftRadius' in node) style.cornerRadii={ topLeft:node.topLeftRadius, topRight:node.topRightRadius, bottomRight:node.bottomRightRadius, bottomLeft:node.bottomLeftRadius };
  if('effects' in node && node.effects!==figma.mixed) style.effects=safeClone(node.effects);
  if('opacity' in node) style.opacity=node.opacity;
  if('blendMode' in node) style.blendMode=safeClone(node.blendMode);
  if('clipsContent' in node) style.clipsContent=node.clipsContent;
  ['isMask','maskType','strokeTopWeight','strokeRightWeight','strokeBottomWeight','strokeLeftWeight','cornerSmoothing'].forEach(function(k){ if(k in node)style[k]=safeClone(node[k]); });
  return style;
}
function layoutOf(node){ var layout={};
  if('layoutMode' in node){
    layout.layoutMode=node.layoutMode;
    layout.primaryAxisAlignItems=node.primaryAxisAlignItems;
    layout.counterAxisAlignItems=node.counterAxisAlignItems;
    layout.primaryAxisSizingMode=node.primaryAxisSizingMode;
    layout.counterAxisSizingMode=node.counterAxisSizingMode;
    layout.itemSpacing=node.itemSpacing;
    layout.paddingLeft=node.paddingLeft; layout.paddingRight=node.paddingRight; layout.paddingTop=node.paddingTop; layout.paddingBottom=node.paddingBottom;
    layout.layoutWrap=node.layoutWrap; layout.counterAxisSpacing=node.counterAxisSpacing;
  }
  if('layoutAlign' in node) layout.layoutAlign=node.layoutAlign;
  if('layoutGrow' in node) layout.layoutGrow=node.layoutGrow;
  if('layoutPositioning' in node) layout.layoutPositioning=node.layoutPositioning;
  if('layoutSizingHorizontal' in node) layout.layoutSizingHorizontal=node.layoutSizingHorizontal;
  if('layoutSizingVertical' in node) layout.layoutSizingVertical=node.layoutSizingVertical;
  if('minWidth' in node) layout.minWidth=safeClone(node.minWidth); if('maxWidth' in node) layout.maxWidth=safeClone(node.maxWidth);
  if('minHeight' in node) layout.minHeight=safeClone(node.minHeight); if('maxHeight' in node) layout.maxHeight=safeClone(node.maxHeight);
  if('constraints' in node) layout.constraints=safeClone(node.constraints);
  return layout;
}
function textOf(node){ if(node.type!=='TEXT') return undefined; var out={
  characters:node.characters, fontSize:safeClone(node.fontSize), fontName:safeClone(node.fontName), fontWeight:safeClone(node.fontWeight),
  lineHeight:safeClone(node.lineHeight), letterSpacing:safeClone(node.letterSpacing), paragraphSpacing:safeClone(node.paragraphSpacing),
  textCase:safeClone(node.textCase), textDecoration:safeClone(node.textDecoration), textAlignHorizontal:node.textAlignHorizontal, textAlignVertical:node.textAlignVertical,
  textAutoResize:node.textAutoResize, paragraphIndent:safeClone(node.paragraphIndent), listSpacing:safeClone(node.listSpacing)
};
  out.hasMissingFont=safeRead('hasMissingFont',function(){return !!node.hasMissingFont;},false);
  out.segments=[];
  out.readWarnings=[];
  try {
    if(typeof node.getStyledTextSegments!=='function') throw new Error('Text segment API unavailable');
    out.segments=node.getStyledTextSegments(['fontName','fontSize','fontWeight','lineHeight','letterSpacing','fills','textCase','textDecoration','textStyleId','fillStyleId','listOptions','listSpacing','paragraphIndent','paragraphSpacing','hyperlink']).map(function(segment){
      var s=safeClone(segment); s.fills=(segment.fills||[]).map(paintToToken).filter(Boolean); return s;
    });
  } catch(e){ out.readWarnings.push({code:'text_segments_failed',message:String(e.message||e),action:'重新导出该文字节点；按预览人工核对混合文字样式。'}); }
  return out;
}
function safeRead(label, fn, fallback){
  try { return fn(); } catch (e) { return fallback; }
}
function readPluginData(node){ return {aiui:getNodeData(node,'aiui'),aiuiNodeId:getAiuiNodeId(node),aiuiProjectId:getNodeData(node,'aiuiProjectId')||null,aiuiRootId:getNodeData(node,'aiuiRootId')||null}; }
function componentOf(node){
  // Some damaged/invalid Component Sets in Figma throw when reading
  // componentProperties/componentPropertyDefinitions/mainComponent.
  // Never let component metadata break the whole export.
  if(node.type==='INSTANCE') {
    var cp = safeRead('componentProperties', function(){ return safeClone(node.componentProperties); }, null);
    var mc = safeRead('mainComponent', function(){ return node.mainComponent; }, null);
    return {
      componentProperties: cp,
      mainComponent: mc ? {
        id: safeRead('mainComponent.id', function(){ return mc.id; }, null),
        name: safeRead('mainComponent.name', function(){ return mc.name; }, null),
        key: safeRead('mainComponent.key', function(){ return mc.key; }, null),
        path: safeRead('mainComponent.path', function(){ return parentPath(mc); }, null)
      } : null,
      readWarnings: cp === null ? ['componentProperties_unreadable'] : []
    };
  }
  if(node.type==='COMPONENT' || node.type==='COMPONENT_SET') {
    var defs = safeRead('componentPropertyDefinitions', function(){ return safeClone(node.componentPropertyDefinitions || null); }, null);
    return {
      key: safeRead('component.key', function(){ return node.key || null; }, null),
      componentPropertyDefinitions: defs,
      readWarnings: defs === null ? ['componentPropertyDefinitions_unreadable'] : []
    };
  }
  return undefined;
}
function flattenText(raw){ var arr=[]; function walk(n){ if(n.text && n.text.characters) arr.push(n.text.characters); if(n.children) n.children.forEach(walk); } walk(raw); return arr.join(' ').trim(); }
function childStats(raw){ var s={texts:0,shapes:0,vectors:0,images:0,children:raw.children?raw.children.length:0}; function walk(n){ if(n===raw){} else { if(n.type==='TEXT')s.texts++; if(['RECTANGLE','ELLIPSE','POLYGON','STAR'].indexOf(n.type)>=0)s.shapes++; if(['VECTOR','BOOLEAN_OPERATION','LINE'].indexOf(n.type)>=0)s.vectors++; if(n.style&&n.style.fills){ for(var i=0;i<n.style.fills.length;i++) if(n.style.fills[i].type==='image') s.images++; } } if(n.children)n.children.forEach(walk); } walk(raw); return s; }

function hasTextDescendant(node){ if(!node) return false; if(node.type==='TEXT') return true; if('children' in node){ for(var i=0;i<node.children.length;i++){ if(hasTextDescendant(node.children[i])) return true; } } return false; }
function hasVectorDescendant(node){ if(!node) return false; if(['VECTOR','BOOLEAN_OPERATION','LINE','ELLIPSE','POLYGON','STAR'].indexOf(node.type)>=0) return true; if('children' in node){ for(var i=0;i<node.children.length;i++){ if(hasVectorDescendant(node.children[i])) return true; } } return false; }
function hasImageFill(node){ if('fills' in node && node.fills!==figma.mixed){ for(var i=0;i<node.fills.length;i++){ if(node.fills[i].type==='IMAGE') return true; } } return false; }
function isLikelyIconAssetNode(node,isRoot){
  if(isRoot || !isVisible(node) || !('exportAsync' in node)) return false;
  var w=node.width||0,h=node.height||0,area=nodeArea(node),name=(node.name||'').toLowerCase();
  if(w<DEFAULTS.minIconSize || h<DEFAULTS.minIconSize || w>256 || h>256 || area<=0 || area>DEFAULTS.maxInlineSvgNodePixels) return false;
  if(hasTextDescendant(node) || hasImageFill(node)) return false;
  var vectorSelf=['VECTOR','BOOLEAN_OPERATION','LINE','ELLIPSE','POLYGON','STAR'].indexOf(node.type)>=0;
  var vectorChild=hasVectorDescendant(node);
  var named=includesAny(name,['icon','icons','ic/','svg','vector','图标','箭头','搜索','logo']);
  var groupLike=['GROUP','FRAME','COMPONENT','COMPONENT_SET','INSTANCE'].indexOf(node.type)>=0;
  if(vectorSelf) return true;
  if(groupLike && vectorChild && (named || w<=96 && h<=96)) return true;
  return false;
}
function iconAssetPath(node){ return 'assets/icons/'+safeName(node.name).toLowerCase()+'-'+getAiuiNodeId(node)+'.svg'; }
function attachAssetRefs(raw,assetByNodeId){ if(assetByNodeId && assetByNodeId[raw.id]){raw.asset=assetByNodeId[raw.id];if(raw.asset.strategy)raw.renderingStrategy=raw.asset.strategy;} if(raw.children) raw.children.forEach(function(c){ attachAssetRefs(c,assetByNodeId); }); return raw; }
function inferInteractionState(name,component){ var s=(name||'').toLowerCase(); var props=component&&component.componentProperties?JSON.stringify(component.componentProperties).toLowerCase():''; var all=s+' '+props; if(includesAny(all,['hover','悬停']))return'hover'; if(includesAny(all,['active','pressed','点击','按下']))return'active'; if(includesAny(all,['disabled','禁用']))return'disabled'; if(includesAny(all,['selected','选中']))return'selected'; if(includesAny(all,['focus','focused','聚焦']))return'focus'; return'default'; }
function guessSemanticTypeFromNode(node){ var name=(node.name||'').toLowerCase();
  if(node.type==='TEXT') return 'Text';
  if(node.type==='INSTANCE'){ if(includesAny(name,['button','btn','按钮']))return'Button'; if(includesAny(name,['input','field','search','form','输入','搜索']))return'Input'; if(includesAny(name,['card','卡片']))return'Card'; if(includesAny(name,['nav','header','导航','顶部']))return'Header'; if(includesAny(name,['sidebar','side bar','侧边']))return'Sidebar'; if(includesAny(name,['tab','tabs','标签']))return'Tabs'; if(includesAny(name,['modal','dialog','弹窗']))return'Modal'; return'ComponentInstance'; }
  if(includesAny(name,['button','btn','按钮']))return'Button'; if(includesAny(name,['card','卡片']))return'Card'; if(includesAny(name,['header','navbar','nav','顶部','导航']))return'Header'; if(includesAny(name,['sidebar','side bar','侧边']))return'Sidebar'; if(includesAny(name,['input','field','search','输入','搜索']))return'Input'; if(includesAny(name,['table','表格']))return'Table'; if(includesAny(name,['list','列表']))return'List'; if(includesAny(name,['footer','底部']))return'Footer'; if(includesAny(name,['modal','dialog','弹窗']))return'Modal';
  if(node.type==='FRAME' || node.type==='SECTION') return 'Frame'; if(node.type==='GROUP') return 'Group';
  if(['VECTOR','BOOLEAN_OPERATION','LINE'].indexOf(node.type)>=0) return 'IconOrVector'; if(['RECTANGLE','ELLIPSE','POLYGON','STAR'].indexOf(node.type)>=0) return 'Shape'; return node.type;
}
function refineSemantic(raw){ var t=raw.semanticType; var stats=childStats(raw); var text=flattenText(raw); var h=raw.height||0,w=raw.width||0;
  if((t==='Frame'||t==='Group') && stats.texts>=1 && h<=72 && w<=360 && (raw.style&&raw.style.fills&&raw.style.fills.length || stats.shapes>=1)) t='ButtonLike';
  if((t==='Frame'||t==='Group') && stats.texts>=1 && h>=28 && h<=80 && includesAny(text,['search','搜索'])) t='Input';
  if((t==='Frame'||t==='Group') && stats.texts>=2 && h>=80 && w>=120 && stats.children>=2) t='CardLike';
  raw.semanticType=t;
  if(raw.children) raw.children.forEach(refineSemantic);
  return raw;
}
function cssHints(raw){ var layout=raw.layout||{}, style=raw.style||{}, hints={};
  if(layout.layoutMode==='HORIZONTAL'||layout.layoutMode==='VERTICAL') { hints.display='flex'; hints.flexDirection=layout.layoutMode==='HORIZONTAL'?'row':'column'; if(typeof layout.itemSpacing==='number') hints.gap=layout.itemSpacing+'px'; hints.alignItems=({MIN:'flex-start',MAX:'flex-end',CENTER:'center',BASELINE:'baseline'})[layout.counterAxisAlignItems]; hints.justifyContent=({MIN:'flex-start',MAX:'flex-end',CENTER:'center',SPACE_BETWEEN:'space-between'})[layout.primaryAxisAlignItems];if(layout.layoutWrap==='WRAP')hints.flexWrap='wrap'; }
  if(layout.layoutMode==='GRID')hints.display='grid';
  if(style.fills && style.fills[0] && style.fills[0].type==='solid') hints[raw.text?'color':'background']=style.fills[0].hex;
  if(style.cornerRadius && style.cornerRadius!=='MIXED') hints.borderRadius=style.cornerRadius+'px';
  if(raw.text){ hints.fontSize=(typeof raw.text.fontSize==='number'?raw.text.fontSize+'px':raw.text.fontSize); var f=raw.text.fontName; if(f&&f.family) hints.fontFamily=f.family; }
  return hints;
}
function basicNode(node,index){ var comp=componentOf(node); var out={
  id:node.id, aiuiNodeId:getAiuiNodeId(node), name:node.name, path:parentPath(node), type:node.type, visible:node.visible, locked:node.locked||false, zIndex:index||0,
  semanticType:guessSemanticTypeFromNode(node), interactionState:inferInteractionState(node.name,comp),
  absoluteBoundingBox:safeClone(node.absoluteBoundingBox||null), relativeTransform:safeClone(node.relativeTransform||null), rotation:safeClone(node.rotation||0),
  style:styleOf(node), layout:layoutOf(node), pluginData:readPluginData(node)
};
  if('x' in node) out.x=node.x; if('y' in node) out.y=node.y; if('width' in node) out.width=node.width; if('height' in node) out.height=node.height;
  out.renderingStrategy=renderingStrategy(node,!node.parent||node.parent.type==='PAGE');
  var t=textOf(node); if(t) out.text=t; if(comp) out.component=comp;
  out.semanticEvidence={source:'heuristic',confidence:'low',reviewRequired:true};
  out.interactionEvidence={source:'name-and-component-properties',confidence:'low',reviewRequired:true};
  out.reactions=safeRead('reactions',function(){return safeClone(node.reactions);},null);
  if('children' in node) out.children=node.children.filter(isVisible).map(function(child,i){return basicNode(child,i);});
  out.cssHints=cssHints(out);
  return out;
}
function rgbDetails(color,opacity){
  if(!color) return null;
  var r=Math.max(0,Math.min(255,Math.round(color.r*255)));
  var g=Math.max(0,Math.min(255,Math.round(color.g*255)));
  var b=Math.max(0,Math.min(255,Math.round(color.b*255)));
  var a=opacity==null?1:Math.max(0,Math.min(1,opacity));
  return {r:r,g:g,b:b,a:a,css:'rgba('+r+', '+g+', '+b+', '+Math.round(a*1000)/1000+')'};
}
function boundColorVariableId(paint){
  var alias=safeRead('paint.boundVariables.color',function(){ return paint&&paint.boundVariables&&paint.boundVariables.color; },null);
  return alias&&typeof alias.id==='string'?alias.id:null;
}
function styleIdFor(node,property,overrideStyleId){
  if(typeof overrideStyleId==='string'&&overrideStyleId) return overrideStyleId;
  var value=safeRead(property==='stroke'?'strokeStyleId':'fillStyleId',function(){ return property==='stroke'?node.strokeStyleId:node.fillStyleId; },null);
  return typeof value==='string'&&value?value:null;
}
async function resolveVariableMeta(id,ctx){
  if(!id) return null;
  if(ctx.variableCache[id]!==undefined) return ctx.variableCache[id];
  var meta={source:'variable',id:id,name:'Unresolved variable '+id,collectionId:null,collectionName:null,collectionModes:[],key:null,resolvedType:'COLOR',remote:null,unresolved:true};
  try{
    var variable=null;
    if(figma.variables){
      if(typeof figma.variables.getVariableByIdAsync==='function') variable=await figma.variables.getVariableByIdAsync(id);
      else if(typeof figma.variables.getVariableById==='function') variable=figma.variables.getVariableById(id);
    }
    if(variable){
      meta.name=variable.name||meta.name; meta.key=variable.key||null; meta.resolvedType=variable.resolvedType||'COLOR'; meta.remote=!!variable.remote; meta.collectionId=variable.variableCollectionId||null; meta.unresolved=false;
      meta.valuesByMode=safeClone(variable.valuesByMode||{});
      if(meta.collectionId){
        try{
          var collection=null;
          if(typeof figma.variables.getVariableCollectionByIdAsync==='function') collection=await figma.variables.getVariableCollectionByIdAsync(meta.collectionId);
          else if(typeof figma.variables.getVariableCollectionById==='function') collection=figma.variables.getVariableCollectionById(meta.collectionId);
          if(collection){ meta.collectionName=collection.name||null; meta.collectionModes=safeClone(collection.modes||[]); }
        }catch(_e){}
      }
    }
  }catch(e){ meta.error=e&&e.message?e.message:String(e); }
  ctx.variableCache[id]=meta;
  return meta;
}
async function resolvePaintStyleMeta(id,ctx){
  if(!id) return null;
  if(ctx.styleCache[id]!==undefined) return ctx.styleCache[id];
  var meta={source:'paint-style',id:id,name:'Unresolved paint style '+id,key:null,remote:null,description:null,unresolved:true};
  try{
    var style=null;
    if(typeof figma.getStyleByIdAsync==='function') style=await figma.getStyleByIdAsync(id);
    else if(typeof figma.getStyleById==='function') style=figma.getStyleById(id);
    if(style){ meta.name=style.name||meta.name; meta.key=style.key||null; meta.remote=!!style.remote; meta.description=style.description||null; meta.unresolved=false; }
  }catch(e){ meta.error=e&&e.message?e.message:String(e); }
  ctx.styleCache[id]=meta;
  return meta;
}
function addTokenUsage(tokens,ctx,meta,usage){
  if(!meta) return;
  var key=meta.source+':'+meta.id;
  var rec=ctx.colorTokenMap[key];
  if(!rec){
    rec={tokenKey:key,source:meta.source,id:meta.id,name:meta.name,key:meta.key||null,collectionId:meta.collectionId||null,collectionName:meta.collectionName||null,collectionModes:meta.collectionModes||[],description:meta.description||null,remote:meta.remote,unresolved:!!meta.unresolved,usageCount:0,resolvedValues:[],usages:[]};
    if(meta.error) rec.error=meta.error;
    ctx.colorTokenMap[key]=rec;
    tokens.colorTokens.push(rec);
    rec.valuesByMode=meta.valuesByMode||{};
  }
  rec.usageCount++;
  rec.usages.push(usage);
  var valueKey=usage.hex+'@'+usage.opacity;
  var valueRec=null;
  for(var i=0;i<rec.resolvedValues.length;i++){ if(rec.resolvedValues[i]._key===valueKey){ valueRec=rec.resolvedValues[i]; break; } }
  if(!valueRec){ valueRec={_key:valueKey,hex:usage.hex,rgb:usage.rgb,opacity:usage.opacity,rgba:usage.rgba,usageCount:0}; rec.resolvedValues.push(valueRec); }
  valueRec.usageCount++;
}
function addRawColorUsage(tokens,usage){
  var rec=tokens.colors[usage.hex];
  if(!rec){ rec={value:usage.hex,hex:usage.hex,rgb:{r:usage.rgb.r,g:usage.rgb.g,b:usage.rgb.b},opacity:usage.opacity,opacities:[],usageCount:0,tokenNames:[],usages:[]}; tokens.colors[usage.hex]=rec; }
  rec.usageCount++;
  rec.usages.push(usage);
  if(rec.opacities.indexOf(usage.opacity)<0) rec.opacities.push(usage.opacity);
}
async function collectPaintUsage(node,paint,property,paintIndex,styleId,tokens,ctx,details){
  if(!paint||paint.visible===false) return;
  if(paint.type&&paint.type.indexOf('GRADIENT')===0&&paint.gradientStops){
    for(var stopIndex=0;stopIndex<paint.gradientStops.length;stopIndex++){
      var stop=paint.gradientStops[stopIndex];
      var stopPaint={type:'SOLID',color:stop.color,opacity:paint.opacity==null?1:paint.opacity,visible:true,boundVariables:stop.boundVariables||null};
      var stopDetails={gradientType:paint.type,gradientStopIndex:stopIndex,gradientStopPosition:stop.position};
      if(details&&details.start!=null) stopDetails.textRange={start:details.start,end:details.end};
      await collectPaintUsage(node,stopPaint,property+'-gradient-stop',paintIndex,styleId,tokens,ctx,stopDetails);
    }
    return;
  }
  if(paint.type!=='SOLID') return;
  var hex=rgbToHex(paint.color); if(!hex) return;
  var opacity=paint.opacity==null?1:paint.opacity, rgb=rgbDetails(paint.color,opacity);
  var variableId=boundColorVariableId(paint);
  if(variableId)await collectVariableReferences({type:'VARIABLE_ALIAS',id:variableId},node,property+'['+paintIndex+'].color',tokens,ctx);
  var nodeOpacity=typeof node.opacity==='number'?node.opacity:1;
  var usage={nodeId:node.id,aiuiNodeId:getAiuiNodeId(node),nodeName:node.name,nodeType:node.type,path:parentPath(node),property:property,paintIndex:paintIndex,hex:hex,rgb:{r:rgb.r,g:rgb.g,b:rgb.b},opacity:opacity,nodeOpacity:nodeOpacity,effectiveOpacity:Math.round(opacity*nodeOpacity*1000)/1000,rgba:rgb.css,variableId:variableId||null,paintStyleId:styleId||null};
  if(details){
    if(details.start!=null) usage.textRange={start:details.start,end:details.end};
    if(details.textRange) usage.textRange=details.textRange;
    if(details.gradientStopIndex!=null){ usage.gradientType=details.gradientType; usage.gradientStopIndex=details.gradientStopIndex; usage.gradientStopPosition=details.gradientStopPosition; }
  }
  addRawColorUsage(tokens,usage);
  tokens.colorUsages.push(usage);
  if(variableId){
    var variableMeta=await resolveVariableMeta(variableId,ctx);
    if(variableMeta&&variableMeta.collectionId){
      var resolvedModes=safeRead('resolvedVariableModes',function(){ return node.resolvedVariableModes||{}; },{})||{};
      usage.variableCollectionId=variableMeta.collectionId;
      usage.variableCollectionName=variableMeta.collectionName||null;
      usage.variableModeId=resolvedModes[variableMeta.collectionId]||null;
      if(usage.variableModeId&&variableMeta.collectionModes){ for(var modeIndex=0;modeIndex<variableMeta.collectionModes.length;modeIndex++){ if(variableMeta.collectionModes[modeIndex].modeId===usage.variableModeId){ usage.variableModeName=variableMeta.collectionModes[modeIndex].name||null; break; } } }
    }
    addTokenUsage(tokens,ctx,variableMeta,usage);
    var colorRec=tokens.colors[hex]; if(colorRec&&colorRec.tokenNames.indexOf(variableMeta.name)<0) colorRec.tokenNames.push(variableMeta.name);
  }
  if(styleId){
    var styleMeta=await resolvePaintStyleMeta(styleId,ctx);
    addTokenUsage(tokens,ctx,styleMeta,usage);
    var styleColorRec=tokens.colors[hex]; if(styleColorRec&&styleColorRec.tokenNames.indexOf(styleMeta.name)<0) styleColorRec.tokenNames.push(styleMeta.name);
  }
}
async function collectVariableReferences(value,node,property,tokens,ctx){
  if(!value||typeof value!=='object')return;
  if(value.type==='VARIABLE_ALIAS'&&value.id){
    if(!tokens.variables)tokens.variables={definitions:{},usages:[]};
    tokens.variables.usages.push({nodeId:node.id,aiuiNodeId:getAiuiNodeId(node),property:property,variableId:value.id,resolvedVariableModes:safeRead('resolvedVariableModes',function(){return safeClone(node.resolvedVariableModes||{});},{})});
    if(Object.prototype.hasOwnProperty.call(tokens.variables.definitions,value.id))return;
    tokens.variables.definitions[value.id]={id:value.id,pending:true};
    var meta=await resolveVariableMeta(value.id,ctx);tokens.variables.definitions[value.id]=meta;
    await collectVariableReferences(meta.valuesByMode,node,'variable:'+value.id+'.valuesByMode',tokens,ctx);
    return;
  }
  var keys=Object.keys(value);
  for(var i=0;i<keys.length;i++)await collectVariableReferences(value[keys[i]],node,property+'.'+keys[i],tokens,ctx);
}
async function collectTokens(node,tokens,ctx){ if(!isVisible(node)) return;
  await collectVariableReferences(safeRead('boundVariables',function(){return safeClone(node.boundVariables);},null),node,'boundVariables',tokens,ctx);
  await collectVariableReferences(safeRead('paintBindings',function(){return safeClone(node.fills);},null),node,'fills',tokens,ctx);
  await collectVariableReferences(safeRead('strokeBindings',function(){return safeClone(node.strokes);},null),node,'strokes',tokens,ctx);
  var i, fillStyleId=styleIdFor(node,'fill',null), strokeStyleId=styleIdFor(node,'stroke',null);
  if('fills' in node && node.fills!==figma.mixed){ for(i=0;i<node.fills.length;i++) await collectPaintUsage(node,node.fills[i],'fill',i,fillStyleId,tokens,ctx,null); }
  if('strokes' in node && node.strokes!==figma.mixed){ for(i=0;i<node.strokes.length;i++) await collectPaintUsage(node,node.strokes[i],'stroke',i,strokeStyleId,tokens,ctx,null); }
  if(node.type==='TEXT'){
    var textRuns=textOf(node).segments||[];
    textRuns.forEach(function(run){var f=run.fontName;if(f&&f.family)tokens.fonts[f.family+' / '+f.style]=f;if(typeof run.fontSize==='number')tokens.fontSizes[String(run.fontSize)]=run.fontSize;if(run.lineHeight)tokens.lineHeights[JSON.stringify(run.lineHeight)]=run.lineHeight;});
    var font=safeClone(node.fontName); if(font&&font.family) tokens.fonts[font.family+' / '+font.style]=font; if(typeof node.fontSize==='number')tokens.fontSizes[String(node.fontSize)]=node.fontSize; if(node.lineHeight&&node.lineHeight!==figma.mixed)tokens.lineHeights[JSON.stringify(safeClone(node.lineHeight))]=safeClone(node.lineHeight);
    if(node.fills===figma.mixed&&typeof node.getStyledTextSegments==='function'){
      var segments=safeRead('getStyledTextSegments',function(){ return node.getStyledTextSegments(['fills','fillStyleId']); },[])||[];
      for(var s=0;s<segments.length;s++){
        var seg=segments[s], segStyleId=styleIdFor(node,'fill',seg.fillStyleId), segFills=seg.fills;
        if(segFills&&segFills!==figma.mixed){ for(var p=0;p<segFills.length;p++) await collectPaintUsage(node,segFills[p],'text-fill',p,segStyleId,tokens,ctx,{start:seg.start,end:seg.end}); }
      }
    }
  }
  if('cornerRadius' in node && typeof node.cornerRadius==='number') tokens.radius[String(node.cornerRadius)]=node.cornerRadius;
  if('layoutMode' in node) ['itemSpacing','paddingLeft','paddingRight','paddingTop','paddingBottom'].forEach(function(k){ if(typeof node[k]==='number') tokens.spacing[String(node[k])]=node[k]; });
  if('effects' in node && node.effects!==figma.mixed) node.effects.forEach(function(e,effectIndex){ if(e.visible!==false) tokens.effects[node.id+'-'+effectIndex]=safeClone(e); });
  if('children' in node){ for(i=0;i<node.children.length;i++) await collectTokens(node.children[i],tokens,ctx); }
}
function finalizeColorTokens(tokens){
  tokens.colorTokens.sort(function(a,b){ return String(a.name).localeCompare(String(b.name)); });
  for(var i=0;i<tokens.colorTokens.length;i++){
    var values=tokens.colorTokens[i].resolvedValues;
    for(var j=0;j<values.length;j++) delete values[j]._key;
  }
}
function makeColorTokenReport(tokens){
  var variables=0,styles=0,unresolved=0;
  tokens.colorTokens.forEach(function(t){ if(t.source==='variable')variables++; if(t.source==='paint-style')styles++; if(t.unresolved)unresolved++; });
  return {schema:'aiui-color-token-report/v1',generatedAt:new Date().toISOString(),summary:{tokenCount:tokens.colorTokens.length,variableTokenCount:variables,paintStyleTokenCount:styles,rawColorCount:Object.keys(tokens.colors).length,colorUsageCount:tokens.colorUsages.length,unresolvedTokenCount:unresolved},tokens:tokens.colorTokens,colors:tokens.colors};
}
function makeColorTokenMarkdown(report){
  var lines=['# Color Token Report','','导出时实际扫描到的颜色 Token、具体色值和使用次数。','','- Token 数量：'+report.summary.tokenCount,'- Figma Variables：'+report.summary.variableTokenCount,'- Paint Styles：'+report.summary.paintStyleTokenCount,'- 实际颜色数量：'+report.summary.rawColorCount,'- 颜色使用记录：'+report.summary.colorUsageCount,'','| Token 名称 | 来源 | 具体色值 | 使用次数 |','|---|---|---|---:|'];
  report.tokens.forEach(function(token){ var values=token.resolvedValues.map(function(v){ return v.hex+' / rgb('+v.rgb.r+', '+v.rgb.g+', '+v.rgb.b+') / opacity '+v.opacity; }).join('<br>')||'未解析'; lines.push('| '+String(token.name||token.id).replace(/\|/g,'\\|')+' | '+token.source+' | '+values+' | '+token.usageCount+' |'); });
  if(!report.tokens.length) lines.push('| 未检测到已绑定的颜色 Token | - | 请检查是否使用了 Figma Variables 或 Paint Styles | 0 |');
  return lines.join('\n')+'\n';
}
function makeSemanticTree(raw){ var keep={ id:raw.id, aiuiNodeId:raw.aiuiNodeId, name:raw.name, path:raw.path, type:raw.type, semanticType:raw.semanticType, interactionState:raw.interactionState, width:raw.width, height:raw.height, layout:raw.layout, style:raw.style, cssHints:raw.cssHints };
  if(raw.text) keep.text=raw.text.characters; if(raw.component) keep.component=raw.component; if(raw.asset) keep.asset=raw.asset; if(raw.children) keep.children=raw.children.map(makeSemanticTree); return keep;
}

function makeDesignIR(raw){
  function roleToElement(t){
    var map={Button:'button',ButtonLike:'button',Input:'input',Header:'header',Sidebar:'aside',Footer:'footer',Card:'section',CardLike:'section',Text:'span',Table:'table',List:'ul',Modal:'dialog',IconOrVector:'svg'};
    return map[t] || 'div';
  }
  function walk(n){
    var ir={
      id:n.id,
      aiuiNodeId:n.aiuiNodeId,
      name:n.name,
      role:n.semanticType,renderingStrategy:n.renderingStrategy,
      sourceType:n.type,
      targetElement:roleToElement(n.semanticType),
      state:n.interactionState||'default',
      semanticEvidence:n.semanticEvidence,interactionEvidence:n.interactionEvidence,reactions:n.reactions,
      relativeTransform:n.relativeTransform,absoluteBoundingBox:n.absoluteBoundingBox,
      frame:{x:n.x||0,y:n.y||0,width:n.width||0,height:n.height||0},
      layout:n.layout||{},
      style:n.style||{},
      cssHints:n.cssHints||{}
    };
    if(n.text) ir.content={text:n.text.characters, typography:n.text};
    if(n.asset) ir.asset=n.asset;
    if(n.component) ir.component=n.component;
    if(n.children) ir.children=n.children.map(walk);
    return ir;
  }
  return { schema:'aiui-design-ir/v0.8', purpose:'Framework-neutral intermediate representation generated from Figma Node API for AI code generation.', root:walk(raw), generationHints:{ preferSemanticHtml:true, preferComponents:true, useTokens:true, useAssetsManifestForAssetSize:true, useAutoLayoutBeforeAbsolute:true } };
}
function verificationCssName(name){ return '--'+String(name||'token').replace(/([a-z0-9])([A-Z])/g,'$1-$2').replace(/[^a-zA-Z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').toLowerCase(); }
function makeFontReport(raw){
  var fonts={},missing=[];
  function walk(n){
    if(n.text){
      if(n.text.hasMissingFont)missing.push({aiuiNodeId:n.aiuiNodeId,name:n.name});
      var runs=n.text.segments&&n.text.segments.length?n.text.segments:[n.text];
      runs.forEach(function(t){
        if(!t.fontName||!t.fontName.family)return;
        var key=JSON.stringify([t.fontName.family,t.fontName.style,t.fontWeight]);
        if(!fonts[key])fonts[key]={family:t.fontName.family,style:t.fontName.style||null,weight:typeof t.fontWeight==='number'?t.fontWeight:null,source:'figma',file:null,availability:'verify-in-browser',usages:[]};
        fonts[key].usages.push({aiuiNodeId:n.aiuiNodeId,name:n.name,start:t.start==null?0:t.start,end:t.end==null?n.text.characters.length:t.end});
      });
    }
    (n.children||[]).forEach(walk);
  }
  walk(raw);
  return {schema:'aiui-font-report/v1',fonts:Object.keys(fonts).map(function(k){return fonts[k];}),missingInFigma:missing,guidance:'使用已有授权字体来源，不自动替换或下载字体。验收读取 Chromium 实际渲染字体；CSS 声明不等于字体已加载。别名或有意的缺字回退需人工核对并记录。'};
}
function renderingStrategy(node,isRoot){
  var reasons=[],hasInteraction=false,complex=false,backdrop=false;
  function scan(n){
    if(!isVisible(n))return;
    if((safeRead('reactions',function(){return n.reactions;},[])||[]).length||['INSTANCE','COMPONENT','COMPONENT_SET'].indexOf(n.type)>=0)hasInteraction=true;
    if(n.isMask||n.type==='BOOLEAN_OPERATION'){complex=true;reasons.push(n.isMask?'mask':'boolean-operation');}
    if(n.type==='VECTOR'&&(n.width>256||n.height>256)){complex=true;reasons.push('large-vector');}
    var fills=safeRead('fills',function(){return n.fills;},[]);
    if(fills&&fills!==figma.mixed&&!fills.some(function(f){return f.type==='IMAGE';})&&fills.filter(function(f){return f.visible!==false;}).length>1){complex=true;reasons.push('layered-paints');}
    (safeRead('effects',function(){return n.effects;},[])||[]).forEach(function(e){if(e.visible!==false&&e.type==='BACKGROUND_BLUR')backdrop=true;});
    if(n.blendMode&&['NORMAL','PASS_THROUGH'].indexOf(n.blendMode)<0)backdrop=true;
    (n.children||[]).forEach(scan);
  }
  scan(node);
  var editable=isRoot||hasTextDescendant(node)||hasInteraction||['INSTANCE','COMPONENT','COMPONENT_SET'].indexOf(node.type)>=0;
  return {mode:complex&&!editable&&!backdrop?'svg-with-png-fallback':'editable',reasons:Array.from(new Set(reasons)),preserveText:hasTextDescendant(node),preserveInteractions:hasInteraction,requiresBackdrop:backdrop,scope:'node-subtree',reviewRequired:backdrop};
}
function makeVerificationConfig(raw,tokens,assetManifest){
  var ids=[],texts=[],implementations=[];
  function walk(n){
    ids.push(n.aiuiNodeId);
    if(n.text&&n.text.characters&&texts.indexOf(n.text.characters)<0)texts.push(n.text.characters);
    var fields=['identity','hierarchy','frame','semanticType','interactionState'];
    if(n.layout&&Object.keys(n.layout).length)fields.push('layout');
    if(n.style&&Object.keys(n.style).length)fields.push('style');
    if(n.text)fields.push('text','typography');
    if(n.component)fields.push('component');
    if(n.asset)fields.push('asset');
    implementations.push({aiuiNodeId:n.aiuiNodeId,nodeName:n.name,path:n.path,requiredFields:fields});
    (n.children||[]).forEach(walk);
  }
  walk(raw);
  var colors=[],tokenVariables=[];
  (tokens.colorTokens||[]).forEach(function(t){ tokenVariables.push({name:t.name||t.id,cssVariable:verificationCssName(t.name||t.id)}); (t.resolvedValues||[]).forEach(function(v){if(v.hex&&colors.indexOf(v.hex)<0)colors.push(v.hex);}); });
  Object.keys(tokens.colors||{}).forEach(function(c){if(/^#/.test(c)&&colors.indexOf(c)<0)colors.push(c);});
  var visualNodes=[],rootBox=raw.absoluteBoundingBox||{x:0,y:0};
  function visualWalk(n,coveredBy){
    var box=n.absoluteBoundingBox;
    if(!coveredBy)visualNodes.push({aiuiNodeId:n.aiuiNodeId,name:n.name,type:n.type,frame:box?{x:box.x-rootBox.x,y:box.y-rootBox.y,width:box.width,height:box.height}:null,text:n.text||null,style:n.style||{},asset:n.asset||null,rotation:n.rotation||0});
    (n.children||[]).forEach(function(c){visualWalk(c,coveredBy||(n.asset&&/^whole-node-/.test(n.asset.exportedAs||'')?n.aiuiNodeId:null));});
  }
  visualWalk(raw,null);
  ids=visualNodes.map(function(n){return n.aiuiNodeId;});
  return {schema:'aiui-verification/v2',meaningOf100Percent:'Static coverage is only an audit of source references; it is not proof of rendering or visual similarity.',policy:{requiredPassRate:100,allowMissingRequired:false},root:{aiuiNodeId:raw.aiuiNodeId,width:raw.width,height:raw.height},requiredImplementations:implementations,requiredAiuiIds:ids,requiredTexts:texts,requiredColors:colors,requiredTokenVariables:tokenVariables,requiredAssets:Array.from(new Set((assetManifest.icons||[]).concat(assetManifest.images||[]).map(function(a){return a.path;}))),visual:{required:true,previewPath:'preview.png',geometryTolerance:2,colorChannelTolerance:32,maxDifferentPixelRatio:0.05,maxRegionDifferentPixelRatio:0.10,fonts:makeFontReport(raw),nodes:visualNodes}};
}
// This function is serialized into the exported standalone verifier. Keep dependencies local.
var visualVerificationSource = "async function runVisualVerification(config,target,packageRoot,fs,path,createRequire){\n  const visual=config.visual;\n  const urlIndex=process.argv.indexOf('--url');\n  const url=urlIndex>=0?process.argv[urlIndex+1]:null;\n  if(!visual)return {status:'unavailable',success:false,reason:'旧基准不含视觉验收数据，请重新导出。'};\n  if(visual.previewAvailable===false)return {status:'unavailable',success:false,reason:'当前导出缺少预览；不能使用旧包遗留的预览进行验收。'};\n  if(!url)return {status:'not-run',success:false,reason:'请增加 --url http://localhost:端口/页面，执行实际渲染验收。'};\n  let browser;\n  try{\n    if(!/^https?:\\/\\//.test(url))throw new Error('--url 必须是 http 或 https 页面地址');\n    const require=createRequire(path.join(target,'package.json'));\n    let chromium,sharp;\n    try{chromium=require('playwright').chromium;sharp=require('sharp');}\n    catch(e){throw new Error('在生成项目安装验收依赖：npm install --save-dev playwright sharp；然后执行 npx playwright install chromium。'+e.message);}\n    const baselinePath=path.resolve(packageRoot,visual.previewPath);\n    if(!fs.existsSync(baselinePath))throw new Error('缺少设计预览，必须重新开启预览导出后验收。');\n    const outDir=path.join(target,'aiui-visual');fs.mkdirSync(outDir,{recursive:true});\n    const launchOptions={headless:true};\n    if(process.env.AIUI_CHROMIUM_PATH)launchOptions.executablePath=process.env.AIUI_CHROMIUM_PATH;\n    browser=await chromium.launch(launchOptions);\n    const page=await browser.newPage({viewport:{width:Math.max(1,Math.ceil(config.root.width)),height:Math.max(1,Math.ceil(config.root.height))},deviceScaleFactor:1,reducedMotion:'reduce',locale:'en-US',timezoneId:'UTC'});\n    await page.goto(url,{waitUntil:'load',timeout:30000});\n    await page.evaluate(async()=>{\n      await document.fonts.ready;\n      await Promise.all(Array.from(document.images).map(img=>img.decode().catch(()=>{})));\n    });\n    await page.addStyleTag({content:'*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}'});\n    const selector='[data-aiui-id=\"'+config.root.aiuiNodeId+'\"]';\n    const root=page.locator(selector);\n    if(await root.count()!==1)throw new Error('页面必须含有唯一根节点 '+selector);\n    await root.waitFor({state:'visible'});\n    const measurements=await page.evaluate(({nodes,rootId})=>{\n      const all=Array.from(document.querySelectorAll('[data-aiui-id]'));\n      const root=all.find(el=>el.getAttribute('data-aiui-id')===rootId),rootBox=root.getBoundingClientRect();\n      function style(el){const s=getComputedStyle(el);return {fontSize:parseFloat(s.fontSize),fontWeight:s.fontWeight,fontFamily:s.fontFamily,lineHeight:s.lineHeight,letterSpacing:s.letterSpacing,color:s.color,backgroundColor:s.backgroundColor,opacity:parseFloat(s.opacity)};}\n      return nodes.map(n=>{\n        const found=all.filter(el=>el.getAttribute('data-aiui-id')===n.aiuiNodeId&&(el===root||root.contains(el)));\n        if(found.length!==1)return {aiuiNodeId:n.aiuiNodeId,count:found.length};\n        const el=found[0],b=el.getBoundingClientRect(),s=getComputedStyle(el);\n        const textNodes=[];const walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let text;\n        while((text=walker.nextNode()))textNodes.push(text);\n        let offset=0;const runs=textNodes.map(t=>{const start=offset;offset+=t.textContent.length;return {start,end:offset,style:style(t.parentElement)};});\n        const imgs=Array.from(el.querySelectorAll('img'));if(el.tagName==='IMG')imgs.push(el);\n        return {aiuiNodeId:n.aiuiNodeId,count:1,visible:s.display!=='none'&&s.visibility==='visible'&&Number(s.opacity)>0,frame:{x:b.x-rootBox.x,y:b.y-rootBox.y,width:b.width,height:b.height},style:style(el),text:el.textContent,runs,brokenImages:imgs.filter(i=>!i.complete||i.naturalWidth===0).length};\n      });\n    },{nodes:visual.nodes,rootId:config.root.aiuiNodeId});\n    const failures=[],checks=[];\n    function check(node,property,expected,actual,pass){const result={aiuiNodeId:node.aiuiNodeId,nodeName:node.name,property,expected,actual,pass};checks.push(result);if(!pass)failures.push(result);}\n    function number(node,property,expected,actual,tolerance){if(typeof expected==='number')check(node,property,expected,actual,Number.isFinite(actual)&&Math.abs(actual-expected)<=tolerance);}\n    function typography(n,t,actual,prefix){\n      number(n,prefix+'fontSize',t.fontSize,actual.fontSize,0.5);\n      number(n,prefix+'fontWeight',t.fontWeight,Number(actual.fontWeight),1);\n      if(t.fontName&&t.fontName.family){const family=actual.fontFamily.split(',')[0].replace(/[\"']/g,'').trim();check(n,prefix+'fontFamily',t.fontName.family,family,family.toLowerCase()===t.fontName.family.toLowerCase());}\n      if(t.lineHeight&&t.lineHeight.unit==='PIXELS')number(n,prefix+'lineHeight',t.lineHeight.value,parseFloat(actual.lineHeight),0.5);\n      if(t.letterSpacing&&t.letterSpacing.unit==='PIXELS')number(n,prefix+'letterSpacing',t.letterSpacing.value,actual.letterSpacing==='normal'?0:parseFloat(actual.letterSpacing),0.5);\n      const fill=t.fills&&t.fills.length===1?t.fills[0]:null;\n      if(fill&&fill.type==='solid'&&fill.opacity===1){const rgb=fill.hex.match(/[\\da-f]{2}/gi).map(v=>parseInt(v,16));const actualRgb=(actual.color.match(/[\\d.]+/g)||[]).map(Number);check(n,prefix+'color',rgb,actualRgb,rgb.every((v,i)=>Math.abs(v-actualRgb[i])<=1)&&(actualRgb.length<4||actualRgb[3]===1));}\n    }\n    // Query actual rendered fonts, not document.fonts.check (which may accept fallback).\n    const cdp=await page.context().newCDPSession(page);\n    await cdp.send('DOM.enable');await cdp.send('CSS.enable');\n    const doc=await cdp.send('DOM.getDocument');\n    const fontChecks=[];\n    for(const n of visual.nodes){\n      if(!n.text||!n.text.characters.trim())continue;\n      const expectedFamilies=Array.from(new Set((n.text.segments&&n.text.segments.length?n.text.segments:[n.text]).map(t=>t.fontName&&t.fontName.family).filter(Boolean)));\n      const escaped=n.aiuiNodeId.replace(/[^a-zA-Z0-9_-]/g,'');\n      if(escaped!==n.aiuiNodeId)throw new Error('Invalid node identity for font inspection');\n      const sel='[data-aiui-id=\"'+escaped+'\"]';\n      const query=await cdp.send('DOM.querySelectorAll',{nodeId:doc.root.nodeId,selector:sel+','+sel+' *'});\n      const rendered=[];\n      for(const nodeId of query.nodeIds){const usage=await cdp.send('CSS.getPlatformFontsForNode',{nodeId});for(const font of usage.fonts)if(font.glyphCount>0&&!rendered.some(f=>f.familyName===font.familyName&&f.postScriptName===font.postScriptName))rendered.push(font);}\n      const normalize=f=>f.toLowerCase().replace(/[\\s_-]/g,'');\n      const unexpected=rendered.filter(f=>!expectedFamilies.some(e=>normalize(e)===normalize(f.familyName)));\n      const pass=expectedFamilies.length>0&&rendered.length>0&&unexpected.length===0;\n      fontChecks.push({aiuiNodeId:n.aiuiNodeId,nodeName:n.name,expectedFamilies,rendered,unexpected,pass,reviewNote:'字体内部名称别名或有意的缺字回退需人工确认；报告不自动认定等价。'});\n      check(n,'renderedFonts',expectedFamilies,rendered.map(f=>f.familyName),pass);\n    }\n    await cdp.detach();\n    for(let i=0;i<visual.nodes.length;i++){\n      const n=visual.nodes[i],m=measurements[i];\n      check(n,'uniqueDOM',1,m.count,m.count===1);if(m.count!==1)continue;\n      if(n.style.opacity!==0)check(n,'visible',true,m.visible,m.visible);\n      if(n.frame)for(const key of ['x','y','width','height'])number(n,'frame.'+key,n.frame[key],m.frame[key],visual.geometryTolerance);\n      if(!(n.asset&&/^whole-node-/.test(n.asset.exportedAs||'')))number(n,'opacity',n.style.opacity,m.style.opacity,0.01);\n      check(n,'loadedImages',0,m.brokenImages,m.brokenImages===0);\n      if(n.text){\n        check(n,'text',n.text.characters,m.text,n.text.characters===m.text);\n        if(n.text.segments&&n.text.segments.length){for(const segment of n.text.segments){const runs=m.runs.filter(r=>r.end>segment.start&&r.start<segment.end);check(n,'textRange.'+segment.start,true,runs.length>0,runs.length>0);for(const run of runs)typography(n,segment,run.style,'text['+segment.start+':'+segment.end+'].');}}\n        else typography(n,n.text,m.style,'text.');\n      }else{\n        const fills=n.style.fills||[];\n        if(!n.asset&&fills.length===1&&fills[0].type==='solid'&&fills[0].opacity===1){const rgb=fills[0].hex.match(/[\\da-f]{2}/gi).map(v=>parseInt(v,16));const actual=(m.style.backgroundColor.match(/[\\d.]+/g)||[]).map(Number);check(n,'backgroundColor',rgb,actual,rgb.every((v,i)=>Math.abs(v-actual[i])<=1)&&(actual.length<4||actual[3]===1));}\n      }\n    }\n    const screenshotPath=path.join(outDir,'actual.png');\n    await root.screenshot({path:screenshotPath,animations:'disabled',caret:'hide',timeout:30000});\n    const expected=await sharp(baselinePath).flatten({background:'#ffffff'}).removeAlpha().raw().toBuffer({resolveWithObject:true});\n    const actual=await sharp(screenshotPath).resize(expected.info.width,expected.info.height,{fit:'fill'}).flatten({background:'#ffffff'}).removeAlpha().raw().toBuffer();\n    const diff=Buffer.alloc(expected.info.width*expected.info.height*3);let different=0;\n    for(let p=0;p<expected.data.length;p+=3){const changed=Math.max(Math.abs(expected.data[p]-actual[p]),Math.abs(expected.data[p+1]-actual[p+1]),Math.abs(expected.data[p+2]-actual[p+2]))>visual.colorChannelTolerance;if(changed)different++;diff[p]=changed?255:expected.data[p];diff[p+1]=changed?0:expected.data[p+1];diff[p+2]=changed?120:expected.data[p+2];}\n    const ratio=different/(expected.info.width*expected.info.height);\n    await sharp(diff,{raw:{width:expected.info.width,height:expected.info.height,channels:3}}).png().toFile(path.join(outDir,'difference.png'));\n    const regionChecks=[],repairItems=[];\n    const width=expected.info.width,height=expected.info.height;\n    const regionThreshold=visual.maxRegionDifferentPixelRatio==null?0.10:visual.maxRegionDifferentPixelRatio;\n    for(let index=0;index<visual.nodes.length;index++){\n      const n=visual.nodes[index],b=n.frame;if(!b||b.width<=0||b.height<=0)continue;\n      const left=Math.max(0,Math.floor(b.x/config.root.width*width)),top=Math.max(0,Math.floor(b.y/config.root.height*height));\n      const right=Math.min(width,Math.ceil((b.x+b.width)/config.root.width*width)),bottom=Math.min(height,Math.ceil((b.y+b.height)/config.root.height*height));\n      if(right<=left||bottom<=top){regionChecks.push({aiuiNodeId:n.aiuiNodeId,status:'outside-baseline',pass:true});continue;}\n      let count=0;\n      for(let y=top;y<bottom;y++)for(let x=left;x<right;x++){const p=(y*width+x)*3;if(Math.max(Math.abs(expected.data[p]-actual[p]),Math.abs(expected.data[p+1]-actual[p+1]),Math.abs(expected.data[p+2]-actual[p+2]))>visual.colorChannelTolerance)count++;}\n      const ratio=count/((right-left)*(bottom-top));\n      const region={aiuiNodeId:n.aiuiNodeId,nodeName:n.name,differentPixelRatio:ratio,threshold:regionThreshold,pass:ratio<=regionThreshold,pixelBounds:{left,top,width:right-left,height:bottom-top}};\n      regionChecks.push(region);\n    }\n    for(const f of failures){\n      const priority=f.property==='renderedFonts'||/font/i.test(f.property)?0:f.property==='uniqueDOM'||f.property.startsWith('frame.')?1:2;\n      repairItems.push({...f,priority,kind:'measured',action:priority===0?'检查字体文件、字体内部名称、字重和回退；修复后重新检查换行与布局。':priority===1?'核对对应节点及父容器布局；根据 expected/actual 修正，保留业务逻辑。':'核对该节点的文字、颜色或素材引用，并重新验收。'});\n    }\n    const badRegions=regionChecks.filter(r=>!r.pass).sort((a,b)=>b.differentPixelRatio-a.differentPixelRatio);\n    for(const region of badRegions){\n      repairItems.push({aiuiNodeId:region.aiuiNodeId,nodeName:region.nodeName,priority:3,kind:'visual-review',differentPixelRatio:region.differentPixelRatio,action:'检查局部对比图；像素差异不能确定原因，不要把推测当成已测量问题。'});\n    }\n    // Limit artifact volume, but evaluate every exported visible region.\n    for(let i=0;i<Math.min(20,badRegions.length);i++){\n      const r=badRegions[i],name='region-'+i,rect=r.pixelBounds;\n      for(const [label,buffer] of [['expected',expected.data],['actual',actual],['difference',diff]])await sharp(buffer,{raw:{width,height,channels:3}}).extract(rect).png().toFile(path.join(outDir,name+'-'+label+'.png'));\n      r.artifacts={expected:'aiui-visual/'+name+'-expected.png',actual:'aiui-visual/'+name+'-actual.png',difference:'aiui-visual/'+name+'-difference.png'};\n    }\n    repairItems.sort((a,b)=>a.priority-b.priority);\n    const repairPlan={schema:'aiui-repair-plan/v1',scope:'current-frame-current-state',items:repairItems,regions:badRegions,workflow:['先修字体与 DOM，再修布局，最后核对局部视觉差异。','每轮修复后用同一 URL 与基准重新运行验收；禁止修改基准和容差。','查看最新 report.json 与 repair-plan.json；success 为 true 才可交付。','无法确认的字体别名或视觉原因应报告待核对，不能声称已通过。']};\n    fs.writeFileSync(path.join(outDir,'repair-plan.json'),JSON.stringify(repairPlan,null,2));\n    fs.writeFileSync(path.join(outDir,'REPAIR.md'),'# 还原修正清单\\n\\n'+repairPlan.workflow.map(x=>'- '+x).join('\\n')+'\\n\\n'+repairItems.map((x,i)=>String(i+1)+'. ['+x.aiuiNodeId+'] '+(x.property||'局部视觉差异')+'：'+x.action).join('\\n')+'\\n');\n    const report={status:'completed',success:failures.length===0&&ratio<=visual.maxDifferentPixelRatio&&badRegions.length===0,url,viewport:{width:config.root.width,height:config.root.height},fonts:fontChecks,regions:regionChecks,repairPlan:'aiui-visual/repair-plan.json',dom:{checks:checks.length,failures,measurements},pixels:{differentPixelRatio:ratio,threshold:visual.maxDifferentPixelRatio,channelTolerance:visual.colorChannelTolerance,pass:ratio<=visual.maxDifferentPixelRatio},artifacts:{actual:'aiui-visual/actual.png',difference:'aiui-visual/difference.png'},limitations:['像素差异不是感知相似度；字体渲染和抗锯齿可能产生差异。','字体内部别名和有意的缺字回退需人工确认；当前只验证导出画板尺寸和当前状态；其他断点、主题和交互需另行验收。','截图缩放到基准分辨率；尺寸误差由独立 DOM 几何检查拦截。']};\n    fs.writeFileSync(path.join(outDir,'report.json'),JSON.stringify(report,null,2));return report;\n  }catch(e){return {status:'error',success:false,reason:String(e.message||e)};}\n  finally{if(browser)await browser.close();}\n}";

function makeVerificationScript(){ return `#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';

const targetArg=process.argv[2];
if(!targetArg){console.error('用法: node verification/verify-aiui.mjs <生成项目目录>');process.exit(2);}
const packageRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const target=path.resolve(targetArg);
if(target===packageRoot){console.error('不能把 AIUI 导出包本身作为生成项目目录；请传入实际生成目录，例如 ./dist。');process.exit(2);}
const config=JSON.parse(fs.readFileSync(path.join(packageRoot,'verification','verification.config.json'),'utf8'));
const implementationMapPath=path.join(target,'.aiui','implementation-map.json');
const allowed=new Set(['.html','.htm','.css','.scss','.sass','.less','.js','.jsx','.ts','.tsx','.vue','.svelte','.svg']);
const ignored=new Set(['node_modules','.git','.next','coverage','verification','.aiui','aiui-visual']);
let files=[];
function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){if(ignored.has(entry.name))continue;const p=path.join(dir,entry.name);if(entry.isDirectory())walk(p);else if(allowed.has(path.extname(entry.name).toLowerCase()))files.push(p);}}
if(!fs.existsSync(target)||!fs.statSync(target).isDirectory()){console.error('生成项目目录不存在: '+target);process.exit(2);}
walk(target);
const corpus=files.map(f=>{try{return fs.readFileSync(f,'utf8');}catch{return '';}}).join('\\n');
const compact=corpus.replace(/\\s+/g,' ');
const plainText=corpus.replace(/<[^>]*>/g,'').replace(/\\s+/g,' ');
const lower=corpus.toLowerCase();
const check=(name,items,found)=>{const missing=items.filter(x=>!found(x));return{name,total:items.length,passed:items.length-missing.length,rate:items.length?Math.round((items.length-missing.length)*10000/items.length)/100:100,missing};};
const results=[];
results.push(check('exportBaseline',config.baselineIssues||[],()=>false));
let implementationMap=null;
try{implementationMap=JSON.parse(fs.readFileSync(implementationMapPath,'utf8'));}catch{}
const mapped=(implementationMap&&implementationMap.nodes)||{};
results.push(check('exportedImplementationCoverage',config.requiredImplementations||[],x=>{const m=mapped[x.aiuiNodeId];if(!m||!m.file||!Array.isArray(m.appliedFields))return false;const fields=x.requiredFields.every(f=>m.appliedFields.includes(f));const source=path.resolve(target,m.file);const rel=path.relative(target,source);return fields&&!!rel&&!rel.startsWith('..')&&!path.isAbsolute(rel)&&files.includes(source)&&fs.existsSync(source)&&!!m.selector;}));
results.push(check('aiuiIds',config.requiredAiuiIds,x=>corpus.includes('data-aiui-id="'+x+'"')||corpus.includes("data-aiui-id='"+x+"'")||corpus.includes('data-aiui-id={"'+x+'"}')));
results.push(check('texts',config.requiredTexts,x=>compact.includes(String(x).replace(/\\s+/g,' '))||plainText.includes(String(x).replace(/\\s+/g,' '))));
results.push(check('colors',config.requiredColors,x=>lower.includes(String(x).toLowerCase())));
results.push(check('tokenVariables',config.requiredTokenVariables,x=>lower.includes(x.cssVariable.toLowerCase())));
results.push(check('assets',config.requiredAssets,x=>{const base=path.basename(x);return (corpus.includes(x)||corpus.includes(base))&&(fs.existsSync(path.join(target,x))||fs.existsSync(path.join(target,'public',x)));}));
const total=results.reduce((n,r)=>n+r.total,0),passed=results.reduce((n,r)=>n+r.passed,0);
const staticSuccess=results.every(r=>r.rate===100);
const visual=process.argv.includes('--static-only')?{status:'not-run',success:false}:await (${visualVerificationSource})(config,target,packageRoot,fs,path,createRequire);
const report={schema:'aiui-verification-result/v2',meaningOf100Percent:'静态引用覆盖率，仅证明源文件引用和字段声明存在；实际渲染结果见 visual，不能将覆盖率解释为视觉相似度。',target,checkedAt:new Date().toISOString(),filesScanned:files.length,totalExportedRequirements:total,executedRequirements:passed,executionCoverage:total?Math.round(passed*10000/total)/100:100,staticSuccess,success:staticSuccess&&visual.success,visual,checks:results};
const out=path.join(target,'aiui-verification-report.json');
fs.writeFileSync(out,JSON.stringify(report,null,2));
fs.mkdirSync(path.join(target,'aiui-visual'),{recursive:true});
fs.writeFileSync(path.join(target,'aiui-visual','report.json'),JSON.stringify(visual,null,2));
console.log(JSON.stringify(report,null,2));
if(process.argv.includes('--static-only')){console.log('仅静态检查，不代表视觉验收通过。');process.exit(staticSuccess?0:1);}
if(!report.success){console.error('\\nAIUI 验收失败：必检项未达到 100%。报告: '+out);process.exit(1);}
console.log('\\nAIUI 验收通过：静态覆盖与实际渲染检查均通过。报告: '+out);
`; }
function makeVerificationReadme(){ return '# AIUI 验收\n\n'+
  '验收分为静态引用覆盖与实际渲染检查。executionCoverage: 100 只表示静态引用齐全，不证明字段真的生效或页面完全一致。必须同时满足 success: true 与 visual.success: true。\n\n'+
  '在生成项目中安装依赖：`npm install --save-dev playwright sharp`，然后 `npx playwright install chromium`。启动页面后执行：\n\n'+
  '`node verification/verify-aiui.mjs <生成项目目录> --url http://localhost:PORT/page`\n\n'+
  '项目根目录必须包含 `.aiui/implementation-map.json`。示例：\n\n'+
  '```json\n{"nodes":{"<aiuiNodeId>":{"file":"src/App.tsx","selector":"[data-aiui-id=...]","appliedFields":["identity","hierarchy","frame","semanticType","interactionState","layout","style"]}}}\n```\n\n'+
  'appliedFields 仅填写已落实的字段。完整 SVG 素材中的子节点可映射到使用该素材的组件，不要求为每条 SVG 路径添加 DOM 标记。其他节点的 data-aiui-id 必须唯一且位于根节点内。混合文本按 UTF-16 区间渲染为 span。\n\n'+
  '输出 `aiui-verification-report.json`、`aiui-visual/report.json`、`aiui-visual/actual.png` 和 `aiui-visual/difference.png`。默认几何误差允许 2 CSS px；像素单通道误差超过 32 计为不同，差异像素不得超过 5%。它们是验收容差，不是相似度承诺；禁止修改导出阈值来获得通过。字体与抗锯齿差异仍需结合差异图核对。\n\n'+
  '另有 font-report.json 字体清单；浏览器验收读取实际用于渲染的字体，别名或缺字回退会报告待核对。每个可见节点的局部差异也独立检查，默认允许 10%；不能用整页小于 5% 掩盖小图标错误。aiui-visual/repair-plan.json 和 REPAIR.md 按字体、结构、布局、视觉顺序给出修正项，前 20 个失败区域附局部对比图。每轮修正后重新运行同一验收。\n\n'+
  '仅检查导出尺寸和当前状态，不推断其他断点、主题或交互。未导出预览、依赖缺失、页面无法打开都会使正式验收失败。`--static-only` 可单独诊断静态引用，其退出码只反映静态检查，报告 success 保持 false，不可据此交付。已有 Chromium 可通过 AIUI_CHROMIUM_PATH 指定。\n'; }

function makeAcceptanceSkillMd(skillName,rootName){ return `---
name: ${skillName}
description: Verify and repair a generated frontend against the design100 acceptance baseline exported for ${String(rootName||'the selected Figma design').replace(/[:\n\r]/g,' ')}. Use when asked to验收、检查、验证或修复该设计的还原结果。
---

# design100 Acceptance

Validate the generated project against this Skill's exported Figma baseline. Static coverage is not proof of rendered implementation. Require visual.success as well as static coverage.

## Required workflow

1. Read \`references/baseline.json\`. In the generated project install \`playwright\` and \`sharp\` as dev dependencies, run \`npx playwright install chromium\`, then start its page.
2. Inspect the generated project and create or update \`<target>/.aiui/implementation-map.json\`. Map every required \`aiuiNodeId\` to a real source file and list only fields actually implemented.
3. Run \`node scripts/verify-aiui.mjs <target-project-directory> --url http://localhost:PORT/page\` from this Skill directory.
4. Treat every missing item as a failure. Do not edit the baseline, remove requirements, or mark fields implemented without a real code location.
5. Fix the generated project, then rerun the verifier until it exits 0 with \`success: true\` and \`executionCoverage: 100\`.
6. Use \`references/baseline.json\` and \`assets/preview.png\` to diagnose failures.
7. Preserve business logic, accessibility and interactions while fixing visual implementation.
8. Report the final command, exit status, coverage, report path and any visual checks that could not be automated.

## Invariants

- Do not validate the design100 export or Skill folder as the target project.
- Do not replace the page with one screenshot or one giant SVG.
- Do not weaken thresholds or modify exported expected values to obtain a pass.
- A completion claim is not evidence; the generated JSON report is required.

${makeComponentReuseGuide()}
`; }
function makeAcceptanceSkillBundle(result,rootName){
  var skillName='design100-acceptance-'+hashString(result.sync.projectId+':'+result.sync.rootAiuiNodeId).slice(0,8);
  function source(path){for(var i=0;i<result.files.length;i++)if(result.files[i].path===path)return result.files[i];return null;}
  function json(path,fallback){var f=source(path);if(!f||f.text===undefined)return fallback;try{return JSON.parse(f.text);}catch(e){return fallback;}}
  var files=[{path:skillName+'/SKILL.md',text:makeAcceptanceSkillMd(skillName,rootName)}];
  var verifier=makeVerificationScript().replace("const config=JSON.parse(fs.readFileSync(path.join(packageRoot,'verification','verification.config.json'),'utf8'));","const baseline=JSON.parse(fs.readFileSync(path.join(packageRoot,'references','baseline.json'),'utf8'));\nconst config=baseline.verification;");
  files.push({path:skillName+'/scripts/verify-aiui.mjs',text:verifier});
  var baseline={
    schema:'ui100-acceptance-baseline/v1',
    manifest:{skillName:skillName,pluginVersion:PLUGIN_VERSION,projectId:result.sync.projectId,rootAiuiNodeId:result.sync.rootAiuiNodeId,rootName:rootName,designVersion:result.snapshot.version,exportedAt:new Date().toISOString(),requiredResult:{success:true,executionCoverage:100,visualSuccess:true}},
    verification:json('verification/verification.config.json',{}),
    uiSpec:json('ui-spec.json',{}),
    semanticTree:json('semantic-tree.json',{}),
    tokens:json('tokens.json',{}),
    colorTokenReport:json('color-token-report.json',{}),
    assetsManifest:json('assets-manifest.json',{}),
    qualityReport:json('quality-report.json',{})
  };
  if(baseline.verification.visual)baseline.verification.visual.previewPath='assets/preview.png';
  files.push({path:skillName+'/references/baseline.json',text:JSON.stringify(baseline,null,2)});
  var preview=source('preview.png');
  if(!preview||preview.bytes===undefined)throw new Error('无法生成验收预览图，请缩小选区尺寸后重试。');
  files.push({path:skillName+'/assets/preview.png',bytes:preview.bytes});
  return {skillName:skillName,files:files};
}
function makeAiuiManifest(rootName, files, stats){
  return {
    schema:'aiui-manifest/v0.8',
    packageType:'AI UI Package',
    packageName:rootName,
    protocol:'AI UI Compiler',
    version:'0.8.0',
    readOrder:['AGENTS.md','agent/component.md','aiui.manifest.json','quality-report.json','font-report.json','design-ir.json','tokens.json','assets-manifest.json','regions.json','preview.png','verification/README.md'],
    primaryFiles:{agent:'AGENTS.md',manifest:'aiui.manifest.json',designIR:'design-ir.json',semanticTree:'semantic-tree.json',uiSpec:'ui-spec.json',tokens:'tokens.json',colorTokenReport:'color-token-report.json',assetsManifest:'assets-manifest.json'},
    agentFiles:['agent/restore.md','agent/mapping.md','agent/layout.md','agent/component.md','agent/quality.md','verification/README.md','verification/verify-aiui.mjs','agent/output.md','agent/update.md'],
    outputTargets:['html-css-js','react','vue','swiftui','flutter'],
    files:files,
    stats:stats
  };
}
function makeComponentReuseGuide(){ return "# Existing Project Component Reuse\n\nBefore writing page code, inspect the target project. The Figma exporter cannot see the target repository; it provides design facts, not an inventory of installed components.\n\n1. Read the target project's AGENTS.md and other applicable development conventions. Inspect dependencies, path aliases, shared UI and business components, theme tokens, existing pages, stories, tests and any existing Code Connect mappings. Follow the project's current framework and component library.\n2. Read candidate components' actual exports, props, variants and usage examples. Record the real files examined and supported props. Do not infer an import path or API from a component name. A Figma component name is a search hint, not proof of a code mapping.\n3. Choose in this order: reuse an existing component; compose existing components; extend compatibly; create a component only if none fits. Native text, wrappers and decorative assets need not become artificial reusable components. Do not install a competing UI library or duplicate existing Button/Input/Dialog components merely to match the screenshot.\n4. Preserve shared defaults, behavior, accessibility and other consumers. Prefer existing props, tokens and scoped variants. For a shared component change, inspect its consumers and run relevant checks. Do not globally restyle a shared component to fix one page.\n5. Maintain `.aiui/component-map.json` in the generated project, alongside the code-map and implementation-map. Keep existing verified mappings across incremental updates; recheck the current API before use. Never overwrite this project-owned map with the export's example.\n6. Record a decision for each Figma instance and each meaningful UI control or repeated business block. Record reuse/compose/extend/create/native/asset, the reason, real component source, import specifier and export name, usage source file, props, and evidence files. For create or extend, include the candidates inspected and why they were unsuitable. Keep property mappings as data, not executable code.\n7. If project files are inaccessible, ask for the target project location. Mark discovery blocked and do not claim that a scan or reuse occurred. If no component library exists, record the inspected paths and use the existing stack to create needed components.\n8. Before delivery, inspect the actual imports and JSX/template usage against the map and run the project build/typecheck and relevant existing tests. Summarize reused, composed, extended and created components with reasons. The visual verifier checks rendering; it does not prove component reuse. A completed map is a record, not proof that its declarations were implemented.\n\n## Map format\n\nThe following is illustrative only; replace placeholders with verified facts. Do not copy it as a completed scan.\n\n```json\n{\n  \"schema\": \"aiui-component-map/v1\",\n  \"discovery\": {\n    \"status\": \"complete\",\n    \"framework\": \"actual framework\",\n    \"inspectedFiles\": [\"actual project convention/dependency/component files\"],\n    \"libraries\": [\"verified existing library, if any\"]\n  },\n  \"nodes\": {\n    \"<aiuiNodeId>\": {\n      \"decision\": \"reuse\",\n      \"reason\": \"Existing component supports the required visual state and behavior\",\n      \"components\": [{\n        \"sourceFile\": \"actual component or package declaration path\",\n        \"importSpecifier\": \"actual import specifier\",\n        \"exportName\": \"actual export name\",\n        \"usageFile\": \"actual consuming page file\",\n        \"props\": {\"actual prop\": \"verified supported value\"}\n      }],\n      \"figmaPropertyMap\": {\"design property\": \"component prop\"},\n      \"evidenceFiles\": [\"actual API and usage files inspected\"],\n      \"candidates\": [],\n      \"checks\": [\"actual validation command and result\"]\n    }\n  }\n}\n```\n"; }
function makeAgentDocs(){
  return [
    {path:'agent/restore.md',text:'# Restore Protocol\n\nRead design-ir.json as the authoritative node data; semantic-tree.json and ui-spec.json are optional compatibility views. Before writing styles, read tokens.json and color-token-report.json. Restore every Figma color token with its original token name, resolved HEX/RGB/RGBA value, opacity, theme mode and usage property. Apply usage records to the corresponding aiuiNodeId and property such as fills, strokes, text color or gradient stop. Keep different semantic tokens separate even when their resolved color values are identical. Use design.svg and preview.png only as visual references. Do not render the entire page as one image or one SVG.\n'},
    {path:'agent/mapping.md',text:'# Mapping Protocol\n\nMap Button/ButtonLike to button, Input to input or form field, Card/CardLike to section/article, Header to header, Sidebar to aside/nav, Footer to footer, Text to semantic text tags, IconOrVector to exported SVG assets. Preserve hierarchy and do not flatten components.\n'},
    {path:'agent/layout.md',text:'# Layout Protocol\n\nFigma Auto Layout maps to CSS flex/grid. Use layoutMode, itemSpacing, padding, alignment, layoutGrow, layoutAlign and constraints from ui-spec.json. Absolute positioning is allowed only for decorative, floating, overlapping, or no-layout nodes.\n'},
    {path:'agent/component.md',text:makeComponentReuseGuide()},
    {path:'agent/quality.md',text:'# Quality Protocol\n\n100% means 100% execution coverage of exported content, not a visual similarity score. Every exported node and every applicable hierarchy, frame, semanticType, interactionState, layout, style, text, typography, component and asset field must have a real code implementation recorded in `.aiui/implementation-map.json`. Before final output verify all text, icons, sizes, colors, tokens, token usage locations, theme modes, typography, Auto Layout, images and hierarchy. Then run `node verification/verify-aiui.mjs <generated-project-directory> --url http://localhost:PORT/page`. A non-zero exit code or executionCoverage below 100 is a failed delivery. Fix every missing item and rerun until `success: true`. Include `aiui-verification-report.json` in the final project.\n'},
    {path:'agent/output.md',text:'# Output Protocol\n\nDefault output: dist/index.html, dist/styles.css, dist/app.js, dist/assets/. For React output: components/, pages/, styles/, assets/. For Vue output: components/, views/, styles/, assets/. Keep code editable, maintainable and production-ready.\n'},
    {path:'agent/update.md',text:makeUpdateAgent()}
  ];
}

function makeUiSpec(raw){ return { schema:'aiui-spec/v0.8', purpose:'Figma Node API export for AI front-end restoration.', restoreOrder:['AGENTS.md','meta.json','tokens.json','color-token-report.json','color-token-report.md','semantic-tree.json','ui-spec.json','mapping-rules.json','assets-manifest.json','quality-report.json','design.svg','assets/'], root:raw, guidance:{ useSemanticHtml:true, preferFlexGridFromAutoLayout:true, preserveTextExactly:true, useSvgAssetsForIcons:true, avoidSingleLargeSvgImage:true, absolutePositionOnlyWhenNoLayoutInfo:true } }; }
function makeMappingRules(){ return { schema:'aiui-mapping-rules/v0.8', rules:[
  { from:'Frame with Auto Layout', to:'div/section/header/main with CSS flex or grid', css:['display:flex','flex-direction from layoutMode','gap from itemSpacing','padding from padding values'] },
  { from:'Button or ButtonLike', to:'button element or reusable Button component', css:['inline-flex','align-items:center','justify-content:center','border-radius from cornerRadius'] },
  { from:'Input', to:'label + input/search container', css:['preserve placeholder text','use icon asset when present'] },
  { from:'Card or CardLike', to:'section/article reusable Card component', css:['background','border','shadow','padding'] },
  { from:'Header', to:'header', css:['flex row','space-between when applicable'] },
  { from:'Sidebar', to:'aside/nav', css:['vertical flex','fixed width when explicit'] },
  { from:'Text', to:'h1-h6/p/span according to size and hierarchy', css:['font-family','font-size','line-height','weight','color'] },
  { from:'IconOrVector', to:'inline svg asset', css:['do not replace with emoji or random icon library','set width and height from asset manifest / Figma node size','preserve viewBox and aspect ratio'] }
]}; }
function makeQualityReport(raw,tokens,stats,options){ return { schema:'aiui-quality-report/v0.8', nodeCount:countNodes(raw), tokenCounts:{ colors:Object.keys(tokens.colors).length, colorTokens:(tokens.colorTokens||[]).length, colorUsages:(tokens.colorUsages||[]).length, fonts:Object.keys(tokens.fonts).length, fontSizes:Object.keys(tokens.fontSizes).length, radius:Object.keys(tokens.radius).length, spacing:Object.keys(tokens.spacing).length }, assetCounts:stats, options:options, warnings:makeWarnings(raw,stats,options) }; }
function makeWarnings(raw,stats,options){ var w=[]; if(countNodes(raw)>800) w.push('节点数量较多，AI 生成时建议按区域拆分。'); if(!options.includeFullSvg) w.push('已关闭 design.svg 完整导出，只能依赖 ui-spec 与局部 assets。'); if(stats.icons>=options.maxIconExports) w.push('图标导出达到上限，可能有部分矢量未导出。'); if(stats.images>=options.maxImageExports) w.push('图片导出达到上限，可能有部分图片未导出。'); return w; }
function makeAgentsMd(rootName){ return '# Restore '+String(rootName).replace(/[\r\n]/g,' ')+'\n\n'+
  'Before implementation, read agent/component.md and scan the target project conventions, dependencies, component APIs and usage examples. Reuse verified existing components first; compose or extend compatibly before creating new ones. Maintain the project-owned .aiui/component-map.json with evidence and reasons. Never invent imports or reset existing mappings. If the project is inaccessible, request its location before claiming reuse.\n\n'+
  '1. Read `aiui.manifest.json`, `quality-report.json`, `font-report.json`, then `design-ir.json` (authoritative node data), `tokens.json` and `assets-manifest.json`. `raw-tree.json`, `semantic-tree.json` and `ui-spec.json` are compatibility views; do not read all copies by default.\n'+
  '2. Inspect `preview.png` at the exported root dimensions, then `regions.json` for region and crop detail references. Report missing assets and unreadable properties from `quality-report.json`; never invent missing design details.\n'+
  '3. Preserve editable layout and text. Apply Auto Layout before absolute positioning. Preserve transforms, masks, gradients and opacity. Use text.segments with their UTF-16 start/end offsets for mixed typography; MIXED is not a CSS value.\n'+
  '4. Use asset.layers in original paint order. Each layer has paintIndex, crop imageTransform, scaleMode, opacity and intrinsicSize. The legacy asset.path is only the first layer. A whole-node-svg replaces its decorative subtree; map descendants to that asset implementation rather than drawing them again.\n'+
  '5. Keep semanticEvidence/interactionEvidence separate from measured design facts. Name-based roles and states require review; reactions are explicit Figma data. Do not invent responsive breakpoints or business behavior from one frame.\n'+
  '6. Keep semantic token names distinct even for equal values. Preserve valuesByMode and VARIABLE_ALIAS references. Use current-node usages for the current appearance.\n'+
  '7. Add data-aiui-id to corresponding DOM nodes; keep `.aiui/code-map.json` and `.aiui/implementation-map.json` with real source paths, selectors and appliedFields. Preserve business logic in existing projects.\n'+
  '8. Follow renderingStrategy. Whole-node graphics include baked paints/effects: use an unstyled wrapper for placement and do not double-apply them. Read `verification/README.md`. Start the generated page and run `node verification/verify-aiui.mjs <project> --url http://localhost:PORT/page`. Static coverage alone is not a pass. Read aiui-visual/repair-plan.json and REPAIR.md. Fix fonts first, then DOM/layout, then inspect local expected/actual/difference images. Repeat the same verification after each repair; do not stop at a failed report. Deliver the latest report and difference image. Do not edit the baseline or thresholds to make tests pass.\n'+
  '9. When update/changeset.json exists, read it first and follow agent/update.md.\n'; }

async function hydrateComponentMetadata(node,raw){
  if(node.type==='INSTANCE'&&typeof node.getMainComponentAsync==='function'){
    try{var main=await node.getMainComponentAsync();if(raw.component)raw.component.mainComponent=main?{id:main.id,name:main.name,key:main.key||null,path:parentPath(main)}:null;}
    catch(e){if(raw.component)raw.component.readWarnings.push('mainComponent_unreadable');}
  }
  var children={};(raw.children||[]).forEach(function(c){children[c.id]=c;});
  for(var i=0;i<(node.children||[]).length;i++){var child=node.children[i];if(children[child.id])await hydrateComponentMetadata(child,children[child.id]);}
}
function collectReadIssues(raw,issues){
  (raw.text&&raw.text.readWarnings||[]).forEach(function(w){issues.push(Object.assign({nodeId:raw.id,aiuiNodeId:raw.aiuiNodeId,nodeName:raw.name,path:raw.path},w));});
  (raw.component&&raw.component.readWarnings||[]).forEach(function(w){issues.push({nodeId:raw.id,aiuiNodeId:raw.aiuiNodeId,nodeName:raw.name,path:raw.path,code:w,message:'组件属性读取失败',action:'检查组件来源并重新导出。'});});
  (raw.children||[]).forEach(function(c){collectReadIssues(c,issues);});
}
// Bound host API waits; a timeout must fail the package rather than silently omit assets.
function exportWithDeadline(node, operation, work, milliseconds){
  return new Promise(function(resolve,reject){
    var settled=false;
    var timer=setTimeout(function(){
      if(settled)return;settled=true;
      var error=new Error(operation+'超时：'+String(node.name||node.id)+'。请缩小选区或重启插件后重试。');
      error.code='EXPORT_TIMEOUT';reject(error);
    },milliseconds||30000);
    Promise.resolve().then(work).then(function(value){
      if(settled)return;settled=true;clearTimeout(timer);resolve(value);
    },function(error){
      if(settled)return;settled=true;clearTimeout(timer);reject(error);
    });
  });
}
function exportNodeAsset(node,settings){
  return exportWithDeadline(node,settings.format+' 素材导出',function(){return node.exportAsync(settings);});
}
function exportIssue(issues,node,code,error,action,property){
  if(error&&error.code==='EXPORT_TIMEOUT')throw error;
  issues.push({nodeId:node.id,aiuiNodeId:getAiuiNodeId(node),nodeName:node.name,path:parentPath(node),code:code,property:property||null,message:String(error&&error.message||error),action:action||'重新导出该节点并核对预览。'});
}
function hashBytes(bytes){var h=2166136261;for(var i=0;i<bytes.length;i++){h^=bytes[i];h=Math.imul(h,16777619);}return ('00000000'+(h>>>0).toString(16)).slice(-8);}
function imageFormat(bytes){
  if(bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71)return 'png';
  if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return 'jpg';
  if(bytes[0]===71&&bytes[1]===73&&bytes[2]===70)return 'gif';
  if(bytes[0]===82&&bytes[1]===73&&bytes[2]===70&&bytes[8]===87&&bytes[9]===69)return 'webp';
  return 'bin';
}
async function collectAssets(node,assets,seenImageHashes,seenIcons,stats,options,manifest,isRoot,issues){
  if(!isVisible(node))return;
  stats.visited=(stats.visited||0)+1;
  if(!stats.lastProgressAt||Date.now()-stats.lastProgressAt>=250){
  stats.lastProgressAt=Date.now();
  progress('4/6 提取素材 '+stats.visited+'/'+(stats.total||'?')+' · '+String(node.name||node.id),66+Math.min(15,15*stats.visited/Math.max(1,stats.total||stats.visited)));
  }
  // Let the host and plugin UI service heartbeat traffic during large traversals.
  if(stats.visited%20===0)await new Promise(function(resolve){setTimeout(resolve,0);});
  issues=issues||[];
  manifest=manifest||{schema:'aiui-assets-manifest/v0.9',icons:[],images:[],byNodeId:{},byAiuiNodeId:{}};
  var aiuiNodeId=getAiuiNodeId(node),layers=[];
  var strategy=renderingStrategy(node,!!isRoot);
  if(strategy.mode==='svg-with-png-fallback'){
    if(options.includeAssets&&stats.icons<options.maxIconExports){
      var base='assets/graphics/'+aiuiNodeId,graphic=null;
      try{
        var svg=bytesToText(await exportNodeAsset(node,{format:'SVG',svgOutlineText:true,svgIdAttribute:true,svgSimplifyStroke:false,useAbsoluteBounds:true}));
        if(!/<svg[\s>]/.test(svg))throw new Error('Invalid SVG');
        var match=svg.match(/viewBox=["']([^"']+)["']/);
        graphic={path:base+'.svg',exportedAs:'whole-node-svg',viewBox:match?match[1]:null,contentHash:hashString(svg)};
        assets.push({path:graphic.path,text:svg});
      }catch(svgError){
        if(svgError&&svgError.code==='EXPORT_TIMEOUT')throw svgError;
        try{
          var scale=Math.min(2,2048/Math.max(1,node.width,node.height));
          var png=await exportNodeAsset(node,{format:'PNG',constraint:{type:'SCALE',value:scale},useAbsoluteBounds:true});
          if(!png||!png.length)throw new Error('Empty PNG');
          graphic={path:base+'.png',exportedAs:'whole-node-png',scale:scale,contentHash:hashBytes(png),svgFailure:String(svgError.message||svgError)};
          assets.push({path:graphic.path,bytes:png});
        }catch(e){exportIssue(issues,node,'graphic_export_failed',e,'重新导出该装饰区域，禁止凭空绘制。');}
      }
      if(graphic){
        Object.assign(graphic,{type:'graphic',nodeId:node.id,aiuiNodeId:aiuiNodeId,nodeName:node.name,width:node.width,height:node.height,strategy:strategy,bakedProperties:['fills','strokes','effects','opacity'],placement:'Use node dimensions and transform on an unstyled wrapper; do not apply baked properties twice.'});
        manifest.icons.push(graphic);manifest.byNodeId[node.id]=graphic;manifest.byAiuiNodeId[aiuiNodeId]=graphic;stats.icons++;return;
      }
    }else exportIssue(issues,node,options.includeAssets?'icon_limit':'assets_disabled','复杂图形素材未导出','开启素材导出或缩小选区。');
  }

  if('fills' in node&&node.fills!==figma.mixed){
    for(var i=0;i<node.fills.length;i++){
      var paint=node.fills[i];
      if(paint.type!=='IMAGE'||paint.visible===false)continue;
      var property='fills['+i+']';
      if(!options.includeAssets){exportIssue(issues,node,'assets_disabled','图片资源导出已关闭','开启资源导出后重试。',property);continue;}
      try{
        if(!paint.imageHash)throw new Error('Missing image hash');
        var cached=seenImageHashes[paint.imageHash];
        if(!cached){
          if(stats.images>=options.maxImageExports){exportIssue(issues,node,'image_limit','图片达到导出上限','拆分选区或使用完整导出模式。',property);continue;}
          var img=figma.getImageByHash(paint.imageHash);
          if(!img)throw new Error('Image unavailable');
          var bytes=await exportWithDeadline(node,'图片读取',function(){return img.getBytesAsync();});
          if(!bytes||!bytes.length)throw new Error('Empty image');
          var ext=imageFormat(bytes),imagePath='assets/images/image-'+hashString(paint.imageHash)+'.'+ext;
          var size=null;
          try{size=await exportWithDeadline(node,'图片尺寸读取',function(){return img.getSizeAsync();});}catch(e){exportIssue(issues,node,'image_size_failed',e,'核对原图尺寸和裁剪结果。',property);}
          cached={path:imagePath,intrinsicSize:size,contentHash:hashBytes(bytes)};
          // Commit to the cache only after the bytes were read successfully.
          assets.push({path:imagePath,bytes:bytes,aiuiNodeId:aiuiNodeId});seenImageHashes[paint.imageHash]=cached;stats.images++;
          if(ext==='bin')exportIssue(issues,node,'image_format_unknown','未知图片编码','检查原图格式并转换为浏览器支持的格式。',property);
        }
        var layer={type:'image',nodeId:node.id,aiuiNodeId:aiuiNodeId,nodeName:node.name,path:cached.path,width:node.width||0,height:node.height||0,intrinsicSize:cached.intrinsicSize,contentHash:cached.contentHash,paintIndex:i,paint:paintToToken(paint),parentPath:parentPath(node),imageHash:paint.imageHash};
        layers.push(layer);manifest.images.push(layer);
      }catch(e){exportIssue(issues,node,'image_export_failed',e,null,property);}
    }
  }
  if(layers.length){
    // Keep the legacy primary path and add lossless per-paint references.
    var ref={type:'image',path:layers[0].path,width:node.width||0,height:node.height||0,aiuiNodeId:aiuiNodeId,layers:layers};
    manifest.byNodeId[node.id]=ref;manifest.byAiuiNodeId[aiuiNodeId]=ref;
  }
  if(isLikelyIconAssetNode(node,!!isRoot)&&!strategy.preserveInteractions&&!strategy.requiresBackdrop&&['INSTANCE','COMPONENT','COMPONENT_SET'].indexOf(node.type)<0){
    if(!options.includeAssets)exportIssue(issues,node,'assets_disabled','图标资源导出已关闭','开启资源导出后重试。');
    else if(stats.icons>=options.maxIconExports)exportIssue(issues,node,'icon_limit','图标达到导出上限','拆分选区或使用完整导出模式。');
    else try{
      if(!seenIcons[aiuiNodeId]){
        var iconPath=iconAssetPath(node),svgBytes=await exportNodeAsset(node,{format:'SVG',svgOutlineText:false,svgIdAttribute:true,svgSimplifyStroke:false}),svgText=bytesToText(svgBytes);
        if(!/<svg[\s>]/.test(svgText))throw new Error('Empty or invalid SVG');
        var viewBoxMatch=svgText.match(/viewBox=["']([^"']+)["']/);
        var icon={type:'icon',nodeId:node.id,aiuiNodeId:aiuiNodeId,nodeName:node.name,path:iconPath,width:node.width||0,height:node.height||0,viewBox:viewBoxMatch?viewBoxMatch[1]:null,parentPath:parentPath(node),exportedAs:'whole-node-svg',contentHash:hashString(svgText)};
        assets.push({path:iconPath,text:svgText,aiuiNodeId:aiuiNodeId});seenIcons[aiuiNodeId]=true;
        manifest.icons.push(icon);manifest.byNodeId[node.id]=icon;manifest.byAiuiNodeId[aiuiNodeId]=icon;stats.icons++;return;
      }
    }catch(e){exportIssue(issues,node,'icon_export_failed',e);}
  }
  if('children' in node)for(var c=0;c<node.children.length;c++)await collectAssets(node.children[c],assets,seenImageHashes,seenIcons,stats,options,manifest,false,issues);
}

function countNodes(node){ var n=1; if(node.children) node.children.forEach(function(c){ n+=countNodes(c); }); return n; }
function normalizeOptions(o){ o=o||{}; var out={}; for(var k in DEFAULTS) out[k]=DEFAULTS[k]; out.includeFullSvg=o.includeFullSvg!==false; out.includePreview=o.includePreview!==false; out.includeAssets=o.includeAssets!==false; out.lightMode=o.lightMode==='fast'?'fast':'full'; if(out.lightMode==='fast'){ out.includeFullSvg=false; out.includePreview=false; out.maxIconExports=40; out.maxImageExports=12; } return out; }
function addSyncFiles(files,sync,snapshot){
  files.push({path:'.aiui/project.json',text:JSON.stringify({schema:'aiui-project/v1',projectId:sync.projectId,rootAiuiNodeId:sync.rootAiuiNodeId,currentVersion:snapshot.version,pluginVersion:PLUGIN_VERSION},null,2)});
  files.push({path:'.aiui/snapshot.json',text:JSON.stringify(snapshot,null,2)});
  files.push({path:'.aiui/code-map.example.json',text:JSON.stringify(makeCodeMapGuide(sync.projectId,snapshot.version),null,2)});
}
async function collectReferencePreviews(root,files,options,issues){
  var regions=[],candidates=[];
  if(!options.includePreview)return {schema:'aiui-regions/v1',regions:regions};
  (root.children||[]).filter(isVisible).forEach(function(n){if(n.type!=='TEXT'&&nodeArea(n)>=10000)candidates.push({node:n,kind:'region'});});
  function crops(n){
    if(!isVisible(n))return;
    var fills=safeRead('fills',function(){return n.fills;},[]);
    if(fills&&fills!==figma.mixed&&fills.some(function(p){return p.visible!==false&&p.type==='IMAGE'&&(p.scaleMode==='CROP'||fills.length>1);}))candidates.push({node:n,kind:'crop-reference'});
    (n.children||[]).forEach(crops);
  }
  crops(root);
  var seen={},selected=[];
  candidates.forEach(function(c){if(!seen[c.node.id]){seen[c.node.id]=true;selected.push(c);}});
  var limit=options.lightMode==='fast'?0:12;
  for(var i=0;i<Math.min(limit,selected.length);i++){
    var c=selected[i],n=c.node,path='references/previews/'+getAiuiNodeId(n)+'.png';
    try{
      var scale=Math.min(1,1024/Math.max(1,n.width||1,n.height||1));
      var bytes=await exportNodeAsset(n,{format:'PNG',constraint:{type:'SCALE',value:scale},useAbsoluteBounds:true});
      if(!bytes||!bytes.length)throw new Error('Empty preview');
      files.push({path:path,bytes:bytes});regions.push({aiuiNodeId:getAiuiNodeId(n),nodeId:n.id,name:n.name,path:path,kind:c.kind,referenceOnly:true,width:n.width,height:n.height,scale:scale});
    }catch(e){exportIssue(issues,n,'reference_preview_failed',e,'可先使用整页预览；需要局部细节时重新导出。');}
  }
  return {schema:'aiui-regions/v1',referenceOnly:true,totalCandidates:selected.length,omitted:Math.max(0,selected.length-limit),regions:regions};
}
async function buildPackage(root,options,mode,baseline){
  options=normalizeOptions(options);
  if(baseline)validateBaselineRoot(root,baseline);
  var sync=ensureSyncContext(root,baseline);
  var issues=[];
  var version=baseline&&baseline.version?baseline.version+1:1;
  progress('1/6 读取 Node Tree 与稳定 ID...', 10); var raw=refineSemantic(basicNode(root,0)); raw.renderingStrategy=renderingStrategy(root,true); await hydrateComponentMetadata(root,raw); var nodeCount=countNodes(raw);
  progress('2/6 提取 Tokens 与颜色变量...', 28); var tokens={ schema:'aiui-tokens/v0.9', colors:{}, colorTokens:[], colorUsages:[], fonts:{}, fontSizes:{}, lineHeights:{}, radius:{}, spacing:{}, effects:{} }; var tokenContext={variableCache:{},styleCache:{},colorTokenMap:{}}; await collectTokens(root,tokens,tokenContext); finalizeColorTokens(tokens); var colorTokenReport=makeColorTokenReport(tokens);
  progress('3/6 导出 design.svg / preview.png...', 48); var svgText=''; var pngBytes=null; var pixels=nodeArea(root);
  if(options.includeFullSvg){
    try{svgText=bytesToText(await root.exportAsync({format:'SVG',svgOutlineText:false,svgIdAttribute:true,svgSimplifyStroke:false}));if(!/<svg[\s>]/.test(svgText))throw new Error('Empty or invalid SVG');}
    catch(e){svgText='';exportIssue(issues,root,'full_svg_failed',e,'重新导出完整 SVG；可先使用结构数据和局部素材。');}
  }
  var previewScale=Math.min(options.previewScale,Math.sqrt(options.maxPreviewPixels/Math.max(1,pixels)),4096/Math.max(1,root.width||1,root.height||1));
  if(options.includePreview){
    try{pngBytes=await root.exportAsync({format:'PNG',constraint:{type:'SCALE',value:previewScale},useAbsoluteBounds:true});if(!pngBytes||!pngBytes.length)throw new Error('Empty preview');}
    catch(e){pngBytes=null;exportIssue(issues,root,'preview_failed',e,'重新导出预览；缺少预览时不能通过视觉验收。');}
  }else exportIssue(issues,root,'preview_disabled','预览导出已关闭','开启预览导出后才能执行视觉验收。');
  progress('4/6 提取 assets/icons/images...',66);
  var assets=[],stats={icons:0,images:0,visited:0,total:countNodes(root)},assetManifest={schema:'aiui-assets-manifest/v0.9',icons:[],images:[],byNodeId:{},byAiuiNodeId:{}};
  await collectAssets(root,assets,{}, {},stats,options,assetManifest,true,issues); attachAssetRefs(raw,assetManifest.byNodeId); var semantic=makeSemanticTree(raw);
  var snapshot=makeSnapshot(raw,sync,version);
  var changeset=null, changedNodes=null;
  if(mode==='update'){
    if(!baseline) throw new Error('没有找到上一次导出快照，请先点击“导出完整包”。');
    changeset=compareSnapshots(baseline,snapshot);
    var changedIdMap={}; changeset.changes.forEach(function(c){ if(c.operation!=='remove')changedIdMap[c.aiuiNodeId]=true; if(c.after&&c.after.parentAiuiNodeId)changedIdMap[c.after.parentAiuiNodeId]=true; });
    changedNodes={schema:'aiui-changed-nodes/v1',projectId:sync.projectId,baseVersion:baseline.version,targetVersion:version,nodes:findRawNodes(raw,changedIdMap)};
  }
  progress('5/6 生成 AI Package 文件...', 82);
  var packageFiles=['AGENTS.md','aiui.manifest.json','agent/restore.md','agent/mapping.md','agent/layout.md','agent/component.md','agent/quality.md','agent/output.md','agent/update.md','verification/README.md','verification/verify-aiui.mjs','verification/verification.config.json','meta.json','raw-tree.json','design-ir.json','semantic-tree.json','ui-spec.json','tokens.json','color-token-report.json','color-token-report.md','mapping-rules.json','assets-manifest.json','quality-report.json','design.svg','preview.png','assets/icons/','assets/images/','assets/vectors/','assets/fonts/','.aiui/project.json','.aiui/snapshot.json','.aiui/code-map.example.json'];
  if(changeset) packageFiles=packageFiles.concat(['update/changeset.json','update/changed-nodes.json','update/UPDATE.md']);
  var meta={ schema:'aiui-package/v0.8', plugin:'design100', pluginVersion:PLUGIN_VERSION, pluginScope:'AI UI Compiler export and incremental update package', exportedAt:new Date().toISOString(), figmaFileName:figma.root.name, pageName:figma.currentPage.name, projectId:sync.projectId,rootAiuiNodeId:sync.rootAiuiNodeId,version:version,mode:mode,root:{id:root.id,aiuiNodeId:raw.aiuiNodeId,name:root.name,type:root.type,width:raw.width,height:raw.height}, options:options, files:packageFiles };
  var referenceFiles=[],regions=await collectReferencePreviews(root,referenceFiles,options,issues);
  collectReadIssues(raw,issues);
  var quality=makeQualityReport(raw,tokens,stats,options); quality.issues=issues; quality.warnings=quality.warnings.concat(issues.map(function(i){return i.nodeName+': '+i.code+' — '+i.message;})); quality.preview={available:!!pngBytes,scale:previewScale}; quality.stableIds={assigned:sync.assignedNodeIds,duplicatesFixed:sync.duplicateNodeIdsFixed,restoredFromBaseline:sync.restoredNodeIds||0};
  var designIR=makeDesignIR(raw);
  var verificationConfig=makeVerificationConfig(raw,tokens,assetManifest);
  verificationConfig.visual.previewAvailable=!!pngBytes;
  verificationConfig.baselineIssues=issues.filter(function(i){return ['image_export_failed','image_limit','icon_export_failed','icon_limit','assets_disabled','text_segments_failed','image_format_unknown','graphic_export_failed'].indexOf(i.code)>=0;});
  var manifest=makeAiuiManifest(root.name,packageFiles,{nodes:nodeCount,icons:stats.icons,images:stats.images,colors:Object.keys(tokens.colors).length,colorTokens:tokens.colorTokens.length,colorUsages:tokens.colorUsages.length,fonts:Object.keys(tokens.fonts).length,projectId:sync.projectId,version:version});
  manifest.incrementalUpdate={supported:true,projectId:sync.projectId,rootAiuiNodeId:sync.rootAiuiNodeId,currentVersion:version,changeset:changeset?'update/changeset.json':null,codeMap:'.aiui/code-map.json',domIdentityAttribute:'data-aiui-id'};
  if(changeset){ manifest.readOrder=['update/UPDATE.md','update/changeset.json','update/changed-nodes.json','agent/update.md'].concat(manifest.readOrder); manifest.primaryFiles.changeset='update/changeset.json'; manifest.primaryFiles.changedNodes='update/changed-nodes.json'; }
  var files=[ {path:'AGENTS.md',text:makeAgentsMd(root.name)}, {path:'aiui.manifest.json',text:JSON.stringify(manifest,null,2)} ];
  makeAgentDocs().forEach(function(f){ files.push(f); });
  files=files.concat([ {path:'verification/README.md',text:makeVerificationReadme()}, {path:'verification/verify-aiui.mjs',text:makeVerificationScript()}, {path:'verification/verification.config.json',text:JSON.stringify(verificationConfig,null,2)}, {path:'meta.json',text:JSON.stringify(meta,null,2)}, {path:'raw-tree.json',text:JSON.stringify(raw,null,2)}, {path:'design-ir.json',text:JSON.stringify(designIR,null,2)}, {path:'semantic-tree.json',text:JSON.stringify(semantic,null,2)}, {path:'ui-spec.json',text:JSON.stringify(makeUiSpec(raw),null,2)}, {path:'tokens.json',text:JSON.stringify(tokens,null,2)}, {path:'color-token-report.json',text:JSON.stringify(colorTokenReport,null,2)}, {path:'color-token-report.md',text:makeColorTokenMarkdown(colorTokenReport)}, {path:'mapping-rules.json',text:JSON.stringify(makeMappingRules(),null,2)}, {path:'assets-manifest.json',text:JSON.stringify(assetManifest,null,2)}, {path:'quality-report.json',text:JSON.stringify(quality,null,2)}, {path:'README_RESTORE.md',text:'# Restore Guide\n\n请先阅读 AGENTS.md、agent/component.md 和 aiui.manifest.json。在当前项目扫描并复用已有组件，维护 .aiui/component-map.json。首次生成代码时必须保留 data-aiui-id，并建立 .aiui/code-map.json。生成完成后必须执行 node verification/verify-aiui.mjs <生成项目目录> --url http://localhost:PORT/page，静态覆盖及视觉检查均通过才能交付。存在 update/changeset.json 时按 agent/update.md 增量修改并重新验收。\n'}, {path:'design.svg',text:svgText} ]);
  if(changeset){ files.push({path:'update/changeset.json',text:JSON.stringify(changeset,null,2)}); files.push({path:'update/changed-nodes.json',text:JSON.stringify(changedNodes,null,2)}); files.push({path:'update/UPDATE.md',text:makeUpdateMarkdown(changeset)}); }
  addSyncFiles(files,sync,snapshot);
  files.push({path:'font-report.json',text:JSON.stringify(makeFontReport(raw),null,2)});
  files.push({path:'regions.json',text:JSON.stringify(regions,null,2)});referenceFiles.forEach(function(f){files.push(f);});
  if(!svgText)files=files.filter(function(f){return f.path!=='design.svg';});
  if(pngBytes) files.push({path:'preview.png',bytes:pngBytes}); assets.forEach(function(a){ files.push(a); });
  var actualFiles=files.map(function(f){return f.path;});meta.files=actualFiles;manifest.files=actualFiles;manifest.readOrder=manifest.readOrder.filter(function(path,i,all){return actualFiles.indexOf(path)>=0&&all.indexOf(path)===i;});
  files.forEach(function(f){if(f.path==='meta.json')f.text=JSON.stringify(meta,null,2);if(f.path==='aiui.manifest.json')f.text=JSON.stringify(manifest,null,2);});
  var updateFiles=null;
  if(changeset){ updateFiles=[
    {path:'AGENTS_UPDATE.md',text:makeUpdateAgent()},
    {path:'agent/component.md',text:makeComponentReuseGuide()},
    {path:'verification/README.md',text:makeVerificationReadme()},
    {path:'verification/verify-aiui.mjs',text:makeVerificationScript()},
    {path:'verification/verification.config.json',text:JSON.stringify(verificationConfig,null,2)},
    {path:'update/changeset.json',text:JSON.stringify(changeset,null,2)},
    {path:'update/changed-nodes.json',text:JSON.stringify(changedNodes,null,2)},
    {path:'update/UPDATE.md',text:makeUpdateMarkdown(changeset)},
    {path:'tokens.json',text:JSON.stringify(tokens,null,2)},
    {path:'color-token-report.json',text:JSON.stringify(colorTokenReport,null,2)},
    {path:'color-token-report.md',text:makeColorTokenMarkdown(colorTokenReport)},
    {path:'assets-manifest.json',text:JSON.stringify(assetManifest,null,2)},
    {path:'.aiui/project.json',text:JSON.stringify({schema:'aiui-project/v1',projectId:sync.projectId,rootAiuiNodeId:sync.rootAiuiNodeId,currentVersion:version,pluginVersion:PLUGIN_VERSION},null,2)}
  ];
  assets.forEach(function(a){updateFiles.push(a);});
  if(pngBytes)updateFiles.push({path:'preview.png',bytes:pngBytes});
  updateFiles.push({path:'quality-report.json',text:JSON.stringify(quality,null,2)});
  updateFiles.push({path:'font-report.json',text:JSON.stringify(makeFontReport(raw),null,2)});
  updateFiles.push({path:'regions.json',text:JSON.stringify(regions,null,2)});referenceFiles.forEach(function(f){updateFiles.push(f);});
  }
  return {sync:sync,snapshot:snapshot,files:files,updateFiles:updateFiles,changeset:changeset,summary:{version:version,baseVersion:baseline?baseline.version:null,nodes:nodeCount,assets:assets.length,colors:Object.keys(tokens.colors).length,colorTokens:tokens.colorTokens.length,colorUsages:tokens.colorUsages.length,fonts:Object.keys(tokens.fonts).length,warnings:quality.warnings.length,stableIdsAssigned:sync.assignedNodeIds,duplicatesFixed:sync.duplicateNodeIdsFixed,restoredNodeIds:sync.restoredNodeIds||0,changes:changeset?changeset.summary:null}};
}
async function buildComponentPackage(selection,options){
  var selected=selection.slice(),ids={};selected.forEach(function(n){ids[n.id]=true;});
  // Selecting a parent and its descendant exports that subtree only once.
  var roots=selected.filter(function(n){var p=n.parent;while(p){if(ids[p.id])return false;p=p.parent;}return true;});
  if(!roots.length)throw new Error('请先在 Figma 中选择要导出的组件或区域，可多选。');
  var files=[],entries=[];
  for(var i=0;i<roots.length;i++){
    var root=roots[i];if(root.removed)throw new Error('所选节点已被删除，请重新选择。');
    if(!isVisible(root)||!root.exportAsync)throw new Error('请选择可见的组件、图层或区域。');
    progress('正在导出组件 '+(i+1)+'/'+roots.length+'：'+root.name,5);
    var result=await buildPackage(root,options,'full',null);
    var folder='components/'+safeName(root.name)+'-'+String(root.id).replace(/[^a-z0-9_-]/gi,'_');
    result.files.forEach(function(f){var copy={path:folder+'/'+f.path};if(f.text!==undefined)copy.text=f.text;if(f.bytes!==undefined)copy.bytes=f.bytes;files.push(copy);});
    entries.push({nodeId:root.id,aiuiNodeId:result.sync.rootAiuiNodeId,name:root.name,type:root.type,path:folder,entry:folder+'/AGENTS.md',warnings:result.summary.warnings});
  }
  files.unshift({path:'components.json',text:JSON.stringify({schema:'aiui-component-package/v1',selectedCount:selected.length,exportedCount:roots.length,components:entries},null,2)});
  files.unshift({path:'AGENTS.md',text:'# Selected component restoration\n\nRead components.json, then agent/component.md. Scan the existing target project first and reuse its components. Each components/<name-id>/ folder is a self-contained design package with its own preview, assets, node data and verifier. Restore only the exported selections, not an entire page. Use each folder as the asset base; do not merge equal relative asset paths blindly. Maintain the target project component-map. Verify each component in an isolated preview route using its own baseline and root data-aiui-id.\n'});
  files.push({path:'agent/component.md',text:makeComponentReuseGuide()});
  return {files:files,count:entries.length,name:'figma-components',components:entries};
}
var componentExportBusy=false;
async function exportComponents(options){
  if(componentExportBusy)return;
  componentExportBusy=true;
  try{var result=await buildComponentPackage((figma.currentPage.selection||[]).slice(),options);figma.ui.postMessage({type:'COMPONENTS_READY',files:result.files,name:result.name,count:result.count});}
  catch(e){figma.ui.postMessage({type:'ERROR',message:'组件导出失败：'+String(e.message||e)});}
  finally{componentExportBusy=false;}
}
var pendingSnapshot=null;
function stageSnapshot(result){
  var id=randomId('export');
  pendingSnapshot={id:id,sync:result.sync,snapshot:result.snapshot};
  return id;
}
async function commitExportSnapshot(id){
  if(!pendingSnapshot||pendingSnapshot.id!==id)return;
  var pending=pendingSnapshot;pendingSnapshot=null;
  if(!await saveSnapshot(pending.sync,pending.snapshot))figma.ui.postMessage({type:'SNAPSHOT_SAVE_WARNING',message:'导出已生成，但快照保存失败。下次更新请选择已导出的旧包。'});
  postSnapshotStatus();
}
async function exportSelected(options){ try{
  var selection=figma.currentPage.selection; if(!selection||selection.length===0){ figma.notify('请先选择一个 Frame / Page 区域'); figma.ui.postMessage({type:'ERROR',message:'请先选择一个 Frame / Page 区域'}); return; }
  var root=selection[0], existingSync=readSyncContext(root), old=existingSync?await loadSnapshot(existingSync):null;
  var result=await buildPackage(root,options,'full',old);
  var exportID=stageSnapshot(result);
  progress('6/6 准备写入 .aiui 文件夹...', 94);
  figma.ui.postMessage({type:'EXPORT_READY',exportID:exportID,mode:'full',name:root.name,version:result.snapshot.version,files:result.files,summary:result.summary});
  postSnapshotStatus(root);
}catch(e){ figma.ui.postMessage({type:'ERROR',message:'导出失败：'+(e&&e.message?e.message:String(e))}); } }
async function exportAcceptanceSkill(options){ try{
  var selection=figma.currentPage.selection;
  if(!selection||selection.length===0){figma.notify('请先选择需要验收的 Frame / Page 区域');figma.ui.postMessage({type:'ERROR',message:'请先选择需要验收的 Frame / Page 区域'});return;}
  options=options||{};
  options.includeFullSvg=true;
  options.includePreview=true;
  options.includeAssets=true;
  options.lightMode='full';
  var root=selection[0],existingSync=readSyncContext(root),old=existingSync?await loadSnapshot(existingSync):null;
  var result=await buildPackage(root,options,'full',old);
  var bundle=makeAcceptanceSkillBundle(result,root.name);
  progress('6/6 验收 Skill 已生成...',96);
  figma.ui.postMessage({type:'SKILL_READY',name:root.name,skillName:bundle.skillName,files:bundle.files,summary:result.summary});
}catch(e){figma.ui.postMessage({type:'ERROR',message:'验收 Skill 导出失败：'+(e&&e.message?e.message:String(e))});} }
async function updateSelected(options){ try{
  var selection=figma.currentPage.selection; if(!selection||selection.length===0){ figma.notify('请先选择上次导出的同一个 Frame'); figma.ui.postMessage({type:'ERROR',message:'请先选择上次导出的同一个 Frame'}); return; }
  var root=selection[0], existingSync=readSyncContext(root), baseline=existingSync?await loadSnapshot(existingSync):null;
  if(!baseline){ figma.ui.postMessage({type:'ERROR',message:'没有找到该 Frame 的上一次导出快照。请先点击“导出完整包”。'}); return; }
  var result=await buildPackage(root,options,'update',baseline);
  if(!result.changeset||result.changeset.changes.length===0){ figma.ui.postMessage({type:'NO_CHANGES',version:baseline.version}); return; }
  var exportID=stageSnapshot(result);
  progress('6/6 准备更新原文件夹...', 94);
  figma.ui.postMessage({type:'UPDATE_READY',exportID:exportID,name:root.name,version:result.snapshot.version,baseVersion:baseline.version,files:result.files,updateFiles:result.updateFiles,changeset:result.changeset,summary:result.summary});
  postSnapshotStatus(root);
}catch(e){ figma.ui.postMessage({type:'ERROR',message:'更新失败：'+(e&&e.message?e.message:String(e))}); } }
async function updateSelectedFromPackage(options,baseline){ try{
  var selection=figma.currentPage.selection;
  if(!selection||selection.length===0){ figma.notify('请先选择上次导出的同一个 Frame'); figma.ui.postMessage({type:'ERROR',message:'请先选择上次导出的同一个 Frame'}); return; }
  if(!baseline||baseline.schema!=='aiui-snapshot/v1'||!baseline.projectId||!baseline.rootAiuiNodeId||!baseline.nodes){
    figma.ui.postMessage({type:'ERROR',message:'选择的旧包无效，未找到可用的设计快照。'});
    return;
  }
  var root=selection[0];
  var result=await buildPackage(root,options,'update',baseline);
  if(!result.changeset||result.changeset.changes.length===0){
    figma.ui.postMessage({type:'NO_CHANGES',version:baseline.version});
    return;
  }
  var exportID=stageSnapshot(result);
  progress('6/6 准备替换原导出包...',94);
  figma.ui.postMessage({type:'UPDATE_READY',exportID:exportID,name:root.name,version:result.snapshot.version,baseVersion:baseline.version,files:result.files,changeset:result.changeset,summary:result.summary});
  postSnapshotStatus(root);
}catch(e){
  figma.ui.postMessage({type:'ERROR',message:'更新失败：'+(e&&e.message?e.message:String(e))});
} }
async function importSnapshotData(snapshot){ try{
  var selection=figma.currentPage.selection; if(!selection||selection.length===0){ figma.ui.postMessage({type:'ERROR',message:'导入旧包前，请先选择它对应的原始 Frame。'}); return; }
  if(!snapshot||snapshot.schema!=='aiui-snapshot/v1'||!snapshot.projectId||!snapshot.rootAiuiNodeId||!snapshot.nodes){ figma.ui.postMessage({type:'ERROR',message:'旧包中的快照格式无效，未找到有效的 .aiui/snapshot.json。'}); return; }
  var root=selection[0], currentByFigmaId={};
  validateBaselineRoot(root,snapshot);
  function walk(node){ currentByFigmaId[node.id]=node; if('children' in node){for(var i=0;i<node.children.length;i++)walk(node.children[i]);} }
  walk(root);
  var matched=0,failed=0;
  Object.keys(snapshot.nodes).forEach(function(id){ var rec=snapshot.nodes[id], node=currentByFigmaId[rec.figmaNodeId]; if(node){ if(setNodeData(node,'aiuiNodeId',rec.aiuiNodeId))matched++; else failed++; } });
  setNodeData(root,'aiuiProjectId',snapshot.projectId);
  setNodeData(root,'aiuiNodeId',snapshot.rootAiuiNodeId);
  setNodeData(root,'aiuiRootId',snapshot.rootAiuiNodeId);
  var sync={projectId:snapshot.projectId,rootAiuiNodeId:snapshot.rootAiuiNodeId};
  await saveSnapshot(sync,snapshot);
  figma.ui.postMessage({type:'IMPORT_SNAPSHOT_READY',version:snapshot.version,matched:matched,failed:failed,nodeCount:snapshot.nodeCount||Object.keys(snapshot.nodes).length});
  postSelection(); postSnapshotStatus(root);
}catch(e){figma.ui.postMessage({type:'ERROR',message:'导入旧包失败：'+(e&&e.message?e.message:String(e))});} }
async function postSnapshotStatus(root){
  try{ root=root||((figma.currentPage.selection||[])[0]); if(!root){figma.ui.postMessage({type:'SNAPSHOT_STATUS',exists:false});return;} var sync=readSyncContext(root); if(!sync){figma.ui.postMessage({type:'SNAPSHOT_STATUS',exists:false});return;} var projectId=sync.projectId; var snap=await loadSnapshot(sync); figma.ui.postMessage({type:'SNAPSHOT_STATUS',exists:!!snap,version:snap?snap.version:null,exportedAt:snap?snap.exportedAt:null,projectId:projectId}); }catch(e){figma.ui.postMessage({type:'SNAPSHOT_STATUS',exists:false});}
}

// Context Notch bridge: bounded selection metadata and local-only preview.
var notchSessionID=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2),notchRevision=0,notchGeneration=0,notchTimer=null;
function notchProperties(node){
  var out={},fields=['x','y','rotation','opacity','cornerRadius','layoutMode','primaryAxisAlignItems','counterAxisAlignItems','primaryAxisSizingMode','counterAxisSizingMode','itemSpacing','paddingTop','paddingBottom','paddingLeft','paddingRight','fontSize','textAlignHorizontal','layoutGrow','layoutAlign','strokeWeight'];
  fields.forEach(function(key){if(key in node&&typeof node[key]!=='symbol')out[key]=String(node[key]).slice(0,2000);});
  if('characters' in node)out.text=String(node.characters||'').slice(0,2000);
  ['fills','strokes','effects','fontName','variantProperties'].forEach(function(key){if(key in node&&node[key]!==figma.mixed){try{var value=JSON.stringify(node[key]);if(value&&value.length<=2000)out[key]=value;}catch(_){}}});
  return out;
}
function notchCollect(root){
  var nodes=[],truncated=false,budget=0;
  function visit(node,parentID,depth){
    if(nodes.length>=120||depth>12){truncated=true;return;}
    var entry={id:String(node.id||'').slice(0,100),name:String(node.name||'').slice(0,500),type:String(node.type||'').slice(0,100),width:Math.max(0,node.width||0),height:Math.max(0,node.height||0),parentID:parentID,properties:notchProperties(node)};
    budget+=JSON.stringify(entry).length;if(budget>60000&&nodes.length){truncated=true;return;}nodes.push(entry);
    if('children' in node)for(var i=0;i<node.children.length;i++){if(nodes.length>=120){truncated=true;break;}visit(node.children[i],node.id,depth+1);}
  }
  if(root)visit(root,null,0);return{nodes:nodes,truncated:truncated};
}
async function notchCapture(epoch){
  var selection=figma.currentPage.selection||[],root=selection[0],tree=notchCollect(root);
  var payload={sessionID:notchSessionID,revision:++notchRevision,fileName:String(figma.root.name||'Figma').slice(0,500),fileKey:figma.fileKey||null,pageName:String(figma.currentPage.name||'').slice(0,500),selectionCount:selection.length,selectedNodes:selection.slice(0,100).map(function(n){return {id:String(n.id).slice(0,100),name:String(n.name||n.type).slice(0,500)};}),nodes:tree.nodes,truncated:tree.truncated,previewBase64:null,previewError:root?'rendering':null};
  figma.ui.postMessage({type:'NOTCH_SELECTION',payload:payload});if(!root)return;
  try{var scale=Math.min(1,720/Math.max(1,root.width,root.height));var bytes=await root.exportAsync({format:'PNG',constraint:{type:'SCALE',value:scale}});if(epoch!==notchGeneration)return;if(bytes.length>2000000)throw new Error('Preview is too large');payload.previewBase64=figma.base64Encode(bytes);payload.previewError=null;}
  catch(error){if(epoch!==notchGeneration)return;payload.previewError=String(error&&error.message||error).slice(0,300);}
  payload.revision=++notchRevision;figma.ui.postMessage({type:'NOTCH_SELECTION',payload:payload});
}
function notchSchedule(){var epoch=++notchGeneration;clearTimeout(notchTimer);figma.ui.postMessage({type:'NOTCH_CHANGING'});notchTimer=setTimeout(function(){notchCapture(epoch).catch(function(error){figma.ui.postMessage({type:'NOTCH_ERROR',message:String(error)});});},80);}
var notchPairingStorageKey='figmadesk.notch.pairing.v1';
async function restoreNotchPairing(){try{var token=await figma.clientStorage.getAsync(notchPairingStorageKey);figma.ui.postMessage({type:'NOTCH_PAIRING',token:typeof token==='string'?token:''});}catch(_){figma.ui.postMessage({type:'NOTCH_PAIRING',token:''});}}
async function saveNotchPairing(token){try{if(typeof token!=='string'||!token)return;await figma.clientStorage.setAsync(notchPairingStorageKey,token);figma.ui.postMessage({type:'NOTCH_PAIRING_SAVED',token:token});}catch(e){figma.ui.postMessage({type:'NOTCH_PAIRING_SAVE_FAILED',message:'配对已连接，但保存失败；将自动重试。'});}}

figma.on('selectionchange', function(){postSelection();postSnapshotStatus();notchSchedule();});
var notchObservedPage=null;
function notchPageChanged(){postSelection();postSnapshotStatus();notchSchedule();}
function observeNotchPage(){
  if(notchObservedPage)notchObservedPage.off('nodechange',notchPageChanged);
  notchObservedPage=figma.currentPage;
  notchObservedPage.on('nodechange',notchPageChanged);
  notchPageChanged();
}
figma.on('currentpagechange',observeNotchPage);
observeNotchPage();
postSelection(); postSnapshotStatus(); notchSchedule();
figma.ui.onmessage=function(msg){ if(!msg||typeof msg.type!=='string')return; if(msg.type==='EXPORT_SAVED'){commitExportSnapshot(msg.exportID);return;} if(msg.type==='RESIZE'){ var h=Math.max(UI_MIN_HEIGHT,Math.min(UI_MAX_HEIGHT,Math.ceil(msg.height||300))); figma.ui.resize(UI_WIDTH,h); } if(msg.type==='EXPORT_COMPONENTS') exportComponents(msg.options); if(msg.type==='EXPORT') exportSelected(msg.options); if(msg.type==='EXPORT_ACCEPTANCE_SKILL') exportAcceptanceSkill(msg.options); if(msg.type==='UPDATE') updateSelected(msg.options); if(msg.type==='UPDATE_FROM_PACKAGE') updateSelectedFromPackage(msg.options,msg.snapshot); if(msg.type==='IMPORT_SNAPSHOT') importSnapshotData(msg.snapshot); if(msg.type==='NOTCH_REFRESH'||msg.type==='NOTCH_UI_READY')notchSchedule(); if(msg.type==='NOTCH_UI_READY')restoreNotchPairing(); if(msg.type==='NOTCH_SAVE_PAIRING')saveNotchPairing(msg.token); if(msg.type==='CLOSE') figma.closePlugin(); };
